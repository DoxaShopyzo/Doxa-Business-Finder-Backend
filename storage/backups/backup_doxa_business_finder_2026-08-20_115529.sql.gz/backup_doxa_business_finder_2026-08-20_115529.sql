-- MySQL dump 10.13  Distrib 8.4.7, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: doxa_business_finder
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_usage_logs`
--

DROP TABLE IF EXISTS `api_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_usage_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `search_id` bigint unsigned DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpoint` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_data` json DEFAULT NULL,
  `response_status` int DEFAULT NULL,
  `response_time_ms` int DEFAULT NULL,
  `estimated_cost` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `credits_charged` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `api_usage_logs_user_id_foreign` (`user_id`),
  KEY `api_usage_logs_search_id_foreign` (`search_id`),
  KEY `api_usage_logs_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `api_usage_logs_provider_created_at_index` (`provider`,`created_at`),
  CONSTRAINT `api_usage_logs_search_id_foreign` FOREIGN KEY (`search_id`) REFERENCES `searches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `api_usage_logs_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `api_usage_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_usage_logs`
--

LOCK TABLES `api_usage_logs` WRITE;
/*!40000 ALTER TABLE `api_usage_logs` DISABLE KEYS */;
INSERT INTO `api_usage_logs` VALUES (1,2,3,21,'google_places','/v1/places:searchText','{\"keyword\": \"Hotel 1\", \"location\": \"Madurai\"}',200,0,0.0350,5,'2026-08-20 06:21:03'),(2,2,3,22,'google_places','/v1/places:searchText','{\"keyword\": \"Hotel 2\", \"location\": \"Madurai\"}',200,0,0.0350,5,'2026-08-20 06:21:20'),(3,2,3,23,'google_places','/v1/places:searchText','{\"keyword\": \"Hotel 5\", \"location\": \"Madurai\"}',200,0,0.0350,5,'2026-08-20 06:21:29');
/*!40000 ALTER TABLE `api_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_id` bigint unsigned DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `audit_logs_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `audit_logs_tenant_id_user_id_index` (`tenant_id`,`user_id`),
  KEY `audit_logs_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `audit_logs_tenant_id_index` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,2,'created','App\\Models\\Lead',1,NULL,'{\"id\": 1, \"phone\": \"9876543211\", \"source\": \"business_finder\", \"status\": \"new\", \"category\": \"restaurant\", \"location\": \"Chennai, Tamil Nadu\", \"priority\": \"warm\", \"tenant_id\": 1, \"created_at\": \"2026-08-15 07:11:55\", \"created_by\": 2, \"updated_at\": \"2026-08-15 07:11:55\", \"business_name\": \"Tamil Nadu Restaurant\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-15 01:41:56'),(2,1,2,'created','App\\Models\\Lead',2,NULL,'{\"id\": 2, \"phone\": \"9999888877\", \"source\": \"business_finder\", \"status\": \"new\", \"category\": \"restaurant\", \"location\": \"T Nagar, Chennai\", \"priority\": \"hot\", \"tenant_id\": 1, \"created_at\": \"2026-08-15 07:15:28\", \"created_by\": 2, \"updated_at\": \"2026-08-15 07:15:28\", \"business_name\": \"Saravana Bhavan\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-15 01:45:29'),(3,1,2,'created','App\\Models\\Search',1,NULL,'{\"id\": 1, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"restaurant\", \"user_id\": 2, \"category\": \"restaurant\", \"latitude\": null, \"location\": \"Chennai\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17 10:12:11\", \"updated_at\": \"2026-08-17 10:12:11\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-17 04:42:11'),(4,1,2,'created','App\\Models\\Search',2,NULL,'{\"id\": 2, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"restaurant\", \"user_id\": 2, \"category\": \"restaurant\", \"latitude\": null, \"location\": \"Chennai\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17 10:14:32\", \"updated_at\": \"2026-08-17 10:14:32\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-17 04:44:33'),(5,1,2,'updated','App\\Models\\Search',2,'{\"id\": 2, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"restaurant\", \"user_id\": 2, \"category\": \"restaurant\", \"latitude\": null, \"location\": \"Chennai\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17T10:14:32.000000Z\", \"updated_at\": \"2026-08-17T10:14:32.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 2, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"restaurant\", \"user_id\": 2, \"category\": \"restaurant\", \"latitude\": null, \"location\": \"Chennai\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17 10:14:32\", \"updated_at\": \"2026-08-17 10:14:34\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-17 04:44:34'),(6,1,2,'created','App\\Models\\Search',3,NULL,'{\"id\": 3, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"shop\", \"user_id\": 2, \"category\": null, \"latitude\": null, \"location\": \"Coimbatore\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17 10:17:21\", \"updated_at\": \"2026-08-17 10:17:21\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-17 04:47:21'),(7,1,2,'updated','App\\Models\\Search',3,'{\"id\": 3, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"shop\", \"user_id\": 2, \"category\": null, \"latitude\": null, \"location\": \"Coimbatore\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17T10:17:21.000000Z\", \"updated_at\": \"2026-08-17T10:17:21.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 3, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"shop\", \"user_id\": 2, \"category\": null, \"latitude\": null, \"location\": \"Coimbatore\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-17 10:17:21\", \"updated_at\": \"2026-08-17 10:17:23\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-17 04:47:24'),(8,1,2,'created','App\\Models\\Lead',3,NULL,'{\"id\": 3, \"phone\": \"+91 98765 43210\", \"source\": \"business_finder\", \"status\": \"new\", \"category\": \"digital_marketing\", \"location\": \"Coimbatore\", \"priority\": \"hot\", \"tenant_id\": 1, \"created_at\": \"2026-08-17 10:17:28\", \"created_by\": 2, \"updated_at\": \"2026-08-17 10:17:28\", \"business_name\": \"Sri Lakshmi Digital Services\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-17 04:47:29'),(9,1,2,'created','App\\Models\\Search',4,NULL,'{\"id\": 4, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"salon\", \"user_id\": 2, \"category\": null, \"latitude\": null, \"location\": \"Trichy\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-20 07:26:33\", \"updated_at\": \"2026-08-20 07:26:33\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 01:56:34'),(10,1,2,'updated','App\\Models\\Search',4,'{\"id\": 4, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"salon\", \"user_id\": 2, \"category\": null, \"latitude\": null, \"location\": \"Trichy\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-20T07:26:33.000000Z\", \"updated_at\": \"2026-08-20T07:26:33.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 4, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"salon\", \"user_id\": 2, \"category\": null, \"latitude\": null, \"location\": \"Trichy\", \"longitude\": null, \"tenant_id\": 1, \"created_at\": \"2026-08-20 07:26:33\", \"updated_at\": \"2026-08-20 07:26:36\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 47}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 01:56:36'),(11,2,3,'created','App\\Models\\Lead',4,NULL,'{\"id\": 4, \"source\": \"manual\", \"status\": \"new\", \"category\": \"test\", \"priority\": \"hot\", \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:09:53\", \"created_by\": 3, \"updated_at\": \"2026-08-20 10:09:53\", \"business_name\": \"ISOLATION_TEST_BIZ\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:39:53'),(12,2,3,'created','App\\Models\\FollowUp',1,NULL,'{\"id\": 1, \"type\": \"call\", \"notes\": \"isolation test\", \"status\": \"scheduled\", \"lead_id\": 4, \"user_id\": 3, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:09:56\", \"updated_at\": \"2026-08-20 10:09:56\", \"followup_date\": \"2026-08-21 00:00:00\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:39:56'),(13,2,3,'created','App\\Models\\Search',5,NULL,'{\"id\": 5, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 3\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:23\", \"updated_at\": \"2026-08-20 10:22:23\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:25'),(14,2,3,'updated','App\\Models\\Search',5,'{\"id\": 5, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 3\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:23.000000Z\", \"updated_at\": \"2026-08-20T10:22:23.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 5, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 3\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:23\", \"updated_at\": \"2026-08-20 10:22:29\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 126}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:29'),(15,2,3,'created','App\\Models\\Search',6,NULL,'{\"id\": 6, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:31\", \"updated_at\": \"2026-08-20 10:22:31\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:31'),(16,2,3,'updated','App\\Models\\Search',6,'{\"id\": 6, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:31.000000Z\", \"updated_at\": \"2026-08-20T10:22:31.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 6, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:31\", \"updated_at\": \"2026-08-20 10:22:33\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:33'),(17,2,3,'created','App\\Models\\Search',7,NULL,'{\"id\": 7, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:34\", \"updated_at\": \"2026-08-20 10:22:34\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:34'),(18,2,3,'updated','App\\Models\\Search',7,'{\"id\": 7, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:34.000000Z\", \"updated_at\": \"2026-08-20T10:22:34.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 7, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:34\", \"updated_at\": \"2026-08-20 10:22:36\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:36'),(19,2,3,'created','App\\Models\\Search',8,NULL,'{\"id\": 8, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 8\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:37\", \"updated_at\": \"2026-08-20 10:22:37\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:38'),(20,2,3,'updated','App\\Models\\Search',8,'{\"id\": 8, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 8\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:37.000000Z\", \"updated_at\": \"2026-08-20T10:22:37.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 8, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 8\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:37\", \"updated_at\": \"2026-08-20 10:22:39\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:39'),(21,2,3,'created','App\\Models\\Search',9,NULL,'{\"id\": 9, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 9\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:40\", \"updated_at\": \"2026-08-20 10:22:40\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:40'),(22,2,3,'updated','App\\Models\\Search',9,'{\"id\": 9, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 9\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:40.000000Z\", \"updated_at\": \"2026-08-20T10:22:40.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 9, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 9\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:40\", \"updated_at\": \"2026-08-20 10:22:42\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:42'),(23,2,3,'created','App\\Models\\Search',10,NULL,'{\"id\": 10, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 7\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:43\", \"updated_at\": \"2026-08-20 10:22:43\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:43'),(24,2,3,'updated','App\\Models\\Search',10,'{\"id\": 10, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 7\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:43.000000Z\", \"updated_at\": \"2026-08-20T10:22:43.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 10, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 7\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:43\", \"updated_at\": \"2026-08-20 10:22:45\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:45'),(25,2,3,'created','App\\Models\\Search',11,NULL,'{\"id\": 11, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 10\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:45\", \"updated_at\": \"2026-08-20 10:22:45\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:45'),(26,2,3,'updated','App\\Models\\Search',11,'{\"id\": 11, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 10\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:45.000000Z\", \"updated_at\": \"2026-08-20T10:22:45.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 11, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 10\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:45\", \"updated_at\": \"2026-08-20 10:22:46\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:46'),(27,2,3,'created','App\\Models\\Search',12,NULL,'{\"id\": 12, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 5\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:47\", \"updated_at\": \"2026-08-20 10:22:47\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:47'),(28,2,3,'updated','App\\Models\\Search',12,'{\"id\": 12, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 5\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:47.000000Z\", \"updated_at\": \"2026-08-20T10:22:47.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 12, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 5\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:47\", \"updated_at\": \"2026-08-20 10:22:50\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:50'),(29,2,3,'created','App\\Models\\Search',13,NULL,'{\"id\": 13, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 4\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:52\", \"updated_at\": \"2026-08-20 10:22:52\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:52'),(30,2,3,'updated','App\\Models\\Search',13,'{\"id\": 13, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 4\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:52.000000Z\", \"updated_at\": \"2026-08-20T10:22:52.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 13, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 4\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:52\", \"updated_at\": \"2026-08-20 10:22:54\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:54'),(31,2,3,'created','App\\Models\\Search',14,NULL,'{\"id\": 14, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 6\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:55\", \"updated_at\": \"2026-08-20 10:22:55\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:55'),(32,2,3,'updated','App\\Models\\Search',14,'{\"id\": 14, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 6\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:22:55.000000Z\", \"updated_at\": \"2026-08-20T10:22:55.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 14, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 6\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:22:55\", \"updated_at\": \"2026-08-20 10:22:56\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:52:56'),(33,2,3,'created','App\\Models\\Search',15,NULL,'{\"id\": 15, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:23:54\", \"updated_at\": \"2026-08-20 10:23:54\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:53:54'),(34,2,3,'updated','App\\Models\\Search',15,'{\"id\": 15, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:23:54.000000Z\", \"updated_at\": \"2026-08-20T10:23:54.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 15, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:23:54\", \"updated_at\": \"2026-08-20 10:23:56\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:53:57'),(35,2,3,'created','App\\Models\\Search',16,NULL,'{\"id\": 16, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:24:10\", \"updated_at\": \"2026-08-20 10:24:10\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:54:10'),(36,2,3,'updated','App\\Models\\Search',16,'{\"id\": 16, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:24:10.000000Z\", \"updated_at\": \"2026-08-20T10:24:10.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 16, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:24:10\", \"updated_at\": \"2026-08-20 10:24:13\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:54:13'),(37,2,3,'created','App\\Models\\Search',17,NULL,'{\"id\": 17, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 4\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:24:14\", \"updated_at\": \"2026-08-20 10:24:14\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:54:14'),(38,2,3,'updated','App\\Models\\Search',17,'{\"id\": 17, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 4\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:24:14.000000Z\", \"updated_at\": \"2026-08-20T10:24:14.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 17, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 4\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:24:14\", \"updated_at\": \"2026-08-20 10:24:17\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:54:18'),(39,2,3,'created','App\\Models\\Search',18,NULL,'{\"id\": 18, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:25:56\", \"updated_at\": \"2026-08-20 10:25:56\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:55:56'),(40,2,3,'updated','App\\Models\\Search',18,'{\"id\": 18, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:25:56.000000Z\", \"updated_at\": \"2026-08-20T10:25:56.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 18, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:25:56\", \"updated_at\": \"2026-08-20 10:25:57\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:55:57'),(41,2,3,'created','App\\Models\\Search',19,NULL,'{\"id\": 19, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:26:13\", \"updated_at\": \"2026-08-20 10:26:13\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:56:13'),(42,2,3,'updated','App\\Models\\Search',19,'{\"id\": 19, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:26:13.000000Z\", \"updated_at\": \"2026-08-20T10:26:13.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 19, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:26:13\", \"updated_at\": \"2026-08-20 10:26:15\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:56:15'),(43,2,3,'created','App\\Models\\Search',20,NULL,'{\"id\": 20, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 9\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:26:17\", \"updated_at\": \"2026-08-20 10:26:17\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:56:17'),(44,2,3,'updated','App\\Models\\Search',20,'{\"id\": 20, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 9\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T10:26:17.000000Z\", \"updated_at\": \"2026-08-20T10:26:17.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 20, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 9\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 10:26:17\", \"updated_at\": \"2026-08-20 10:26:19\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 04:56:19'),(45,2,3,'updated','App\\Models\\Lead',4,'{\"id\": 4, \"email\": null, \"notes\": null, \"phone\": null, \"source\": \"manual\", \"status\": \"new\", \"website\": null, \"category\": \"test\", \"location\": null, \"priority\": \"hot\", \"tenant_id\": 2, \"won_value\": null, \"created_at\": \"2026-08-20T10:09:53.000000Z\", \"created_by\": 3, \"deleted_at\": null, \"updated_at\": \"2026-08-20T10:09:53.000000Z\", \"assigned_to\": null, \"lost_reason\": null, \"probability\": null, \"business_name\": \"ISOLATION_TEST_BIZ\", \"custom_fields\": null, \"expected_value\": null, \"place_reference\": null, \"search_result_id\": null, \"formatted_address\": null, \"opportunity_score\": null}','{\"id\": 4, \"email\": null, \"notes\": null, \"phone\": null, \"source\": \"manual\", \"status\": \"contacted\", \"website\": null, \"category\": \"test\", \"location\": null, \"priority\": \"hot\", \"tenant_id\": 2, \"won_value\": null, \"created_at\": \"2026-08-20 10:09:53\", \"created_by\": 3, \"deleted_at\": null, \"updated_at\": \"2026-08-20 10:54:45\", \"assigned_to\": null, \"lost_reason\": null, \"probability\": null, \"business_name\": \"ISOLATION_TEST_BIZ\", \"custom_fields\": null, \"expected_value\": null, \"place_reference\": null, \"search_result_id\": null, \"formatted_address\": null, \"opportunity_score\": null}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 05:24:45'),(46,2,3,'export','App\\Models\\Lead',NULL,NULL,'{\"count\": 1, \"format\": \"csv\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 05:24:52'),(47,NULL,1,'export_credits','App\\Models\\CreditWallet',NULL,NULL,'{\"count\": 4, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:03'),(48,NULL,1,'export_payments','App\\Models\\Payment',NULL,NULL,'{\"count\": 1, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:03'),(49,NULL,1,'export_reports',NULL,NULL,NULL,'{\"type\": \"monthly_analytics\", \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:03'),(50,NULL,1,'export_api_usage','App\\Models\\ApiUsageLog',NULL,NULL,'{\"count\": 0, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:03'),(51,NULL,1,'export_security_logs','App\\Models\\LoginLog',NULL,NULL,'{\"count\": 30, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:03'),(52,NULL,1,'export_audit_logs','App\\Models\\AuditLog',NULL,NULL,'{\"count\": 51, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:03'),(53,NULL,1,'export_credits','App\\Models\\CreditWallet',NULL,NULL,'{\"count\": 4, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:06'),(54,NULL,1,'export_payments','App\\Models\\Payment',NULL,NULL,'{\"count\": 1, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:07'),(55,NULL,1,'export_reports',NULL,NULL,NULL,'{\"type\": \"monthly_analytics\", \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:07'),(56,NULL,1,'export_api_usage','App\\Models\\ApiUsageLog',NULL,NULL,'{\"count\": 0, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:07'),(57,NULL,1,'export_security_logs','App\\Models\\LoginLog',NULL,NULL,'{\"count\": 31, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:07'),(58,NULL,1,'export_audit_logs','App\\Models\\AuditLog',NULL,NULL,'{\"count\": 57, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:07'),(59,NULL,1,'export_credits','App\\Models\\CreditWallet',NULL,NULL,'{\"count\": 4, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:25'),(60,NULL,1,'export_payments','App\\Models\\Payment',NULL,NULL,'{\"count\": 1, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:25'),(61,NULL,1,'export_reports',NULL,NULL,NULL,'{\"type\": \"monthly_analytics\", \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:25'),(62,NULL,1,'export_api_usage','App\\Models\\ApiUsageLog',NULL,NULL,'{\"count\": 0, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:25'),(63,NULL,1,'export_security_logs','App\\Models\\LoginLog',NULL,NULL,'{\"count\": 32, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:25'),(64,NULL,1,'export_audit_logs','App\\Models\\AuditLog',NULL,NULL,'{\"count\": 63, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:25'),(65,NULL,1,'export_credits','App\\Models\\CreditWallet',NULL,NULL,'{\"count\": 4, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:35'),(66,NULL,1,'export_payments','App\\Models\\Payment',NULL,NULL,'{\"count\": 1, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:35'),(67,NULL,1,'export_reports',NULL,NULL,NULL,'{\"type\": \"monthly_analytics\", \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:35'),(68,NULL,1,'export_api_usage','App\\Models\\ApiUsageLog',NULL,NULL,'{\"count\": 0, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:35'),(69,NULL,1,'export_security_logs','App\\Models\\LoginLog',NULL,NULL,'{\"count\": 33, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:35'),(70,NULL,1,'export_audit_logs','App\\Models\\AuditLog',NULL,NULL,'{\"count\": 69, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:35'),(71,NULL,1,'export_credits','App\\Models\\CreditWallet',NULL,NULL,'{\"count\": 4, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:49'),(72,NULL,1,'export_payments','App\\Models\\Payment',NULL,NULL,'{\"count\": 1, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:49'),(73,NULL,1,'export_reports',NULL,NULL,NULL,'{\"type\": \"monthly_analytics\", \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:49'),(74,NULL,1,'export_api_usage','App\\Models\\ApiUsageLog',NULL,NULL,'{\"count\": 0, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:50'),(75,NULL,1,'export_security_logs','App\\Models\\LoginLog',NULL,NULL,'{\"count\": 34, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:50'),(76,NULL,1,'export_audit_logs','App\\Models\\AuditLog',NULL,NULL,'{\"count\": 75, \"format\": \"csv\"}','127.0.0.1','Symfony','2026-08-20 06:04:50'),(77,2,3,'created','App\\Models\\Search',21,NULL,'{\"id\": 21, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:51:01\", \"updated_at\": \"2026-08-20 11:51:01\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:21:01'),(78,2,3,'updated','App\\Models\\Search',21,'{\"id\": 21, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T11:51:01.000000Z\", \"updated_at\": \"2026-08-20T11:51:01.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 21, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 1\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:51:01\", \"updated_at\": \"2026-08-20 11:51:03\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:21:03'),(79,2,3,'created','App\\Models\\Search',22,NULL,'{\"id\": 22, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:51:18\", \"updated_at\": \"2026-08-20 11:51:18\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:21:18'),(80,2,3,'updated','App\\Models\\Search',22,'{\"id\": 22, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T11:51:18.000000Z\", \"updated_at\": \"2026-08-20T11:51:18.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 22, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 2\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:51:18\", \"updated_at\": \"2026-08-20 11:51:20\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:21:20'),(81,2,3,'created','App\\Models\\Search',23,NULL,'{\"id\": 23, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 5\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:51:23\", \"updated_at\": \"2026-08-20 11:51:23\", \"api_provider\": \"google_places\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:21:24'),(82,2,3,'updated','App\\Models\\Search',23,'{\"id\": 23, \"radius\": null, \"status\": \"pending\", \"filters\": null, \"keyword\": \"Hotel 5\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20T11:51:23.000000Z\", \"updated_at\": \"2026-08-20T11:51:23.000000Z\", \"api_provider\": \"google_places\"}','{\"id\": 23, \"radius\": null, \"status\": \"completed\", \"filters\": null, \"keyword\": \"Hotel 5\", \"user_id\": 3, \"category\": null, \"latitude\": null, \"location\": \"Madurai\", \"longitude\": null, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:51:23\", \"updated_at\": \"2026-08-20 11:51:28\", \"api_provider\": \"google_places\", \"credits_used\": 5, \"result_count\": 10, \"response_time_ms\": 0}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:21:28'),(83,2,3,'created','App\\Models\\Lead',5,NULL,'{\"id\": 5, \"source\": \"manual\", \"status\": \"new\", \"category\": \"test\", \"priority\": \"hot\", \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:53:26\", \"created_by\": 3, \"updated_at\": \"2026-08-20 11:53:26\", \"business_name\": \"ISOLATION_TEST_BIZ_8799\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:23:26'),(84,2,3,'created','App\\Models\\FollowUp',2,NULL,'{\"id\": 2, \"type\": \"call\", \"notes\": \"isolation test\", \"status\": \"scheduled\", \"lead_id\": 5, \"user_id\": 3, \"tenant_id\": 2, \"created_at\": \"2026-08-20 11:53:27\", \"updated_at\": \"2026-08-20 11:53:27\", \"followup_date\": \"2026-08-21 00:00:00\"}','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','2026-08-20 06:23:28');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('doxa-business-finder-cache-1b6453892473a467d07372d45eb05abc2031647a','i:8;',1787226870),('doxa-business-finder-cache-1b6453892473a467d07372d45eb05abc2031647a:timer','i:1787226870;',1787226870),('doxa-business-finder-cache-5c785c036466adea360111aa28563bfd556b5fba','i:5;',1787226856),('doxa-business-finder-cache-5c785c036466adea360111aa28563bfd556b5fba:timer','i:1787226855;',1787226856),('doxa-business-finder-cache-77de68daecd823babbb58edb1c8e14d7106e83bb','i:60;',1787226865),('doxa-business-finder-cache-77de68daecd823babbb58edb1c8e14d7106e83bb:timer','i:1787226865;',1787226865),('doxa-business-finder-cache-test_ratelimit@test.com|127.0.0.1','i:3;',1787226898),('doxa-business-finder-cache-test_ratelimit@test.com|127.0.0.1:timer','i:1787226897;',1787226897);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_packages`
--

DROP TABLE IF EXISTS `credit_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credits` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `bonus_credits` int NOT NULL DEFAULT '0',
  `validity_days` int DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_packages`
--

LOCK TABLES `credit_packages` WRITE;
/*!40000 ALTER TABLE `credit_packages` DISABLE KEYS */;
INSERT INTO `credit_packages` VALUES (1,'Starter Pack',1000,499.00,'INR',0,NULL,1,1,'2026-08-14 08:23:12','2026-08-14 08:23:12'),(2,'Growth Pack',3000,999.00,'INR',300,NULL,1,2,'2026-08-14 08:23:12','2026-08-14 08:23:12'),(3,'Pro Pack',10000,1999.00,'INR',1500,NULL,1,3,'2026-08-14 08:23:12','2026-08-14 08:23:12'),(4,'Agency Pack',50000,4999.00,'INR',10000,NULL,1,4,'2026-08-14 08:23:13','2026-08-14 08:23:13');
/*!40000 ALTER TABLE `credit_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_transactions`
--

DROP TABLE IF EXISTS `credit_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `wallet_id` bigint unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `credits` int NOT NULL,
  `balance_before` int NOT NULL,
  `balance_after` int NOT NULL,
  `reference_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idempotency_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credit_transactions_idempotency_key_unique` (`idempotency_key`),
  KEY `credit_transactions_user_id_foreign` (`user_id`),
  KEY `credit_transactions_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `credit_transactions_wallet_id_index` (`wallet_id`),
  KEY `credit_transactions_reference_type_reference_id_index` (`reference_type`,`reference_id`),
  CONSTRAINT `credit_transactions_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `credit_transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `credit_wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_transactions`
--

LOCK TABLES `credit_transactions` WRITE;
/*!40000 ALTER TABLE `credit_transactions` DISABLE KEYS */;
INSERT INTO `credit_transactions` VALUES (1,1,NULL,1,'search',5,50,45,'App\\Models\\Search',2,'Business search: restaurant',NULL,'2026-08-17 04:44:35'),(2,1,NULL,1,'search',5,45,40,'App\\Models\\Search',3,'Business search: shop',NULL,'2026-08-17 04:47:24'),(3,1,NULL,1,'search',5,40,35,'App\\Models\\Search',4,'Business search: salon',NULL,'2026-08-20 01:56:36'),(4,2,3,2,'search',5,50,45,'App\\Models\\Search',5,'Business search: Hotel 3',NULL,'2026-08-20 04:52:30'),(5,2,3,2,'search',5,45,40,'App\\Models\\Search',6,'Business search: Hotel 1',NULL,'2026-08-20 04:52:34'),(6,2,3,2,'search',5,40,35,'App\\Models\\Search',7,'Business search: Hotel 2',NULL,'2026-08-20 04:52:37'),(7,2,3,2,'search',5,35,30,'App\\Models\\Search',8,'Business search: Hotel 8',NULL,'2026-08-20 04:52:39'),(8,2,3,2,'search',5,30,25,'App\\Models\\Search',9,'Business search: Hotel 9',NULL,'2026-08-20 04:52:42'),(9,2,3,2,'search',5,25,20,'App\\Models\\Search',10,'Business search: Hotel 7',NULL,'2026-08-20 04:52:45'),(10,2,3,2,'search',5,20,15,'App\\Models\\Search',11,'Business search: Hotel 10',NULL,'2026-08-20 04:52:47'),(11,2,3,2,'search',5,15,10,'App\\Models\\Search',12,'Business search: Hotel 5',NULL,'2026-08-20 04:52:50'),(12,2,3,2,'search',5,10,5,'App\\Models\\Search',13,'Business search: Hotel 4',NULL,'2026-08-20 04:52:54'),(13,2,3,2,'search',5,5,0,'App\\Models\\Search',14,'Business search: Hotel 6',NULL,'2026-08-20 04:52:56'),(14,2,3,2,'search',5,15,10,'App\\Models\\Search',15,'Business search: Hotel 1',NULL,'2026-08-20 04:53:57'),(15,2,3,2,'search',5,10,5,'App\\Models\\Search',16,'Business search: Hotel 2',NULL,'2026-08-20 04:54:13'),(16,2,3,2,'search',5,5,0,'App\\Models\\Search',17,'Business search: Hotel 4',NULL,'2026-08-20 04:54:18'),(17,2,3,2,'search',5,15,10,'App\\Models\\Search',18,'Business search: Hotel 1',NULL,'2026-08-20 04:55:57'),(18,2,3,2,'search',5,10,5,'App\\Models\\Search',19,'Business search: Hotel 2',NULL,'2026-08-20 04:56:15'),(19,2,3,2,'search',5,5,0,'App\\Models\\Search',20,'Business search: Hotel 9',NULL,'2026-08-20 04:56:19'),(20,5,NULL,4,'purchase',3300,0,3300,'App\\Models\\Payment',1,'Credit package: Growth Pack',NULL,'2026-08-20 05:21:54'),(21,2,3,2,'search',5,15,10,'App\\Models\\Search',21,'Business search: Hotel 1',NULL,'2026-08-20 06:21:03'),(22,2,3,2,'search',5,10,5,'App\\Models\\Search',22,'Business search: Hotel 2',NULL,'2026-08-20 06:21:20'),(23,2,3,2,'search',5,5,0,'App\\Models\\Search',23,'Business search: Hotel 5',NULL,'2026-08-20 06:21:29'),(24,5,NULL,4,'purchase',3300,3300,6600,'App\\Models\\Payment',2,'Credit package: Growth Pack',NULL,'2026-08-20 06:24:34');
/*!40000 ALTER TABLE `credit_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_wallets`
--

DROP TABLE IF EXISTS `credit_wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credit_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `balance` int NOT NULL DEFAULT '0',
  `total_earned` int NOT NULL DEFAULT '0',
  `total_spent` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `credit_wallets_tenant_id_user_id_unique` (`tenant_id`,`user_id`),
  KEY `credit_wallets_user_id_foreign` (`user_id`),
  KEY `credit_wallets_tenant_id_index` (`tenant_id`),
  CONSTRAINT `credit_wallets_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `credit_wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_wallets`
--

LOCK TABLES `credit_wallets` WRITE;
/*!40000 ALTER TABLE `credit_wallets` DISABLE KEYS */;
INSERT INTO `credit_wallets` VALUES (1,1,NULL,35,50,15,'2026-08-14 08:43:53','2026-08-20 01:56:36'),(2,2,NULL,0,50,95,'2026-08-20 04:38:57','2026-08-20 06:21:29'),(3,3,NULL,50,50,0,'2026-08-20 04:39:00','2026-08-20 04:39:01'),(4,5,NULL,6600,6600,0,'2026-08-20 05:21:53','2026-08-20 06:24:34');
/*!40000 ALTER TABLE `credit_wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deals`
--

DROP TABLE IF EXISTS `deals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `lead_id` bigint unsigned NOT NULL,
  `quotation_id` bigint unsigned DEFAULT NULL,
  `deal_value` decimal(12,2) NOT NULL,
  `service` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `closing_date` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deals_lead_id_foreign` (`lead_id`),
  KEY `deals_quotation_id_foreign` (`quotation_id`),
  KEY `deals_created_by_foreign` (`created_by`),
  KEY `deals_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  CONSTRAINT `deals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `deals_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `deals_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `deals_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deals`
--

LOCK TABLES `deals` WRITE;
/*!40000 ALTER TABLE `deals` DISABLE KEYS */;
/*!40000 ALTER TABLE `deals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `followups`
--

DROP TABLE IF EXISTS `followups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `followups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `lead_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `followup_date` date NOT NULL,
  `followup_time` time DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'call',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'scheduled',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `outcome` text COLLATE utf8mb4_unicode_ci,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `followups_lead_id_foreign` (`lead_id`),
  KEY `followups_user_id_foreign` (`user_id`),
  KEY `followups_tenant_id_user_id_status_index` (`tenant_id`,`user_id`,`status`),
  KEY `followups_tenant_id_followup_date_index` (`tenant_id`,`followup_date`),
  CONSTRAINT `followups_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `followups_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `followups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `followups`
--

LOCK TABLES `followups` WRITE;
/*!40000 ALTER TABLE `followups` DISABLE KEYS */;
INSERT INTO `followups` VALUES (1,2,4,3,'2026-08-21',NULL,'call','scheduled','isolation test',NULL,NULL,'2026-08-20 04:39:56','2026-08-20 04:39:56'),(2,2,5,3,'2026-08-21',NULL,'call','scheduled','isolation test',NULL,NULL,'2026-08-20 06:23:27','2026-08-20 06:23:27');
/*!40000 ALTER TABLE `followups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `payment_id` bigint unsigned DEFAULT NULL,
  `invoice_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` text COLLATE utf8mb4_unicode_ci,
  `subtotal` decimal(10,2) NOT NULL,
  `gst_percent` decimal(5,2) NOT NULL DEFAULT '18.00',
  `gst_amount` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `status` enum('draft','paid','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `issued_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_tenant_id_foreign` (`tenant_id`),
  KEY `invoices_payment_id_foreign` (`payment_id`),
  CONSTRAINT `invoices_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_activities`
--

DROP TABLE IF EXISTS `lead_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `lead_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `lead_activities_user_id_foreign` (`user_id`),
  KEY `lead_activities_lead_id_created_at_index` (`lead_id`,`created_at`),
  KEY `lead_activities_tenant_id_user_id_index` (`tenant_id`,`user_id`),
  CONSTRAINT `lead_activities_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lead_activities_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lead_activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_activities`
--

LOCK TABLES `lead_activities` WRITE;
/*!40000 ALTER TABLE `lead_activities` DISABLE KEYS */;
INSERT INTO `lead_activities` VALUES (1,1,1,2,'system','Lead created',NULL,'2026-08-15 01:41:57'),(2,1,2,2,'system','Lead created',NULL,'2026-08-15 01:45:29'),(3,1,3,2,'system','Lead created',NULL,'2026-08-17 04:47:29'),(4,2,4,3,'system','Lead created',NULL,'2026-08-20 04:39:54'),(5,2,4,3,'system','Follow-up scheduled for 2026-08-21 00:00:00',NULL,'2026-08-20 04:39:56'),(6,2,4,3,'status_change','Status changed from new to contacted','{\"new_status\": \"contacted\", \"old_status\": \"new\"}','2026-08-20 05:24:45'),(7,2,5,3,'system','Lead created',NULL,'2026-08-20 06:23:27'),(8,2,5,3,'system','Follow-up scheduled for 2026-08-21 00:00:00',NULL,'2026-08-20 06:23:28');
/*!40000 ALTER TABLE `lead_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_assignments`
--

DROP TABLE IF EXISTS `lead_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_assignments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `lead_id` bigint unsigned NOT NULL,
  `assigned_by` bigint unsigned NOT NULL,
  `assigned_to` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `lead_assignments_lead_id_foreign` (`lead_id`),
  KEY `lead_assignments_assigned_by_foreign` (`assigned_by`),
  KEY `lead_assignments_assigned_to_foreign` (`assigned_to`),
  KEY `lead_assignments_tenant_id_assigned_to_index` (`tenant_id`,`assigned_to`),
  CONSTRAINT `lead_assignments_assigned_by_foreign` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lead_assignments_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lead_assignments_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lead_assignments_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_assignments`
--

LOCK TABLES `lead_assignments` WRITE;
/*!40000 ALTER TABLE `lead_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `assigned_to` bigint unsigned DEFAULT NULL,
  `search_result_id` bigint unsigned DEFAULT NULL,
  `place_reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formatted_address` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'business_finder',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `priority` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'warm',
  `opportunity_score` int DEFAULT NULL,
  `expected_value` decimal(12,2) DEFAULT NULL,
  `probability` int DEFAULT NULL,
  `won_value` decimal(12,2) DEFAULT NULL,
  `lost_reason` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `custom_fields` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `leads_created_by_foreign` (`created_by`),
  KEY `leads_assigned_to_foreign` (`assigned_to`),
  KEY `leads_search_result_id_foreign` (`search_result_id`),
  KEY `leads_tenant_id_status_index` (`tenant_id`,`status`),
  KEY `leads_tenant_id_assigned_to_index` (`tenant_id`,`assigned_to`),
  KEY `leads_tenant_id_priority_created_at_index` (`tenant_id`,`priority`,`created_at`),
  KEY `leads_tenant_id_source_index` (`tenant_id`,`source`),
  KEY `leads_tenant_id_phone_index` (`tenant_id`,`phone`),
  KEY `leads_tenant_id_website_index` (`tenant_id`,`website`),
  KEY `leads_tenant_id_place_reference_index` (`tenant_id`,`place_reference`),
  CONSTRAINT `leads_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leads_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `leads_search_result_id_foreign` FOREIGN KEY (`search_result_id`) REFERENCES `search_results` (`id`) ON DELETE SET NULL,
  CONSTRAINT `leads_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (1,1,2,NULL,NULL,NULL,'Tamil Nadu Restaurant','restaurant','Chennai, Tamil Nadu',NULL,'9876543211',NULL,NULL,'business_finder','new','warm',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-15 01:41:55','2026-08-15 01:41:55',NULL),(2,1,2,NULL,NULL,NULL,'Saravana Bhavan','restaurant','T Nagar, Chennai',NULL,'9999888877',NULL,NULL,'business_finder','new','hot',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-15 01:45:28','2026-08-15 01:45:28',NULL),(3,1,2,NULL,NULL,NULL,'Sri Lakshmi Digital Services','digital_marketing','Coimbatore',NULL,'+91 98765 43210',NULL,NULL,'business_finder','new','hot',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-17 04:47:28','2026-08-17 04:47:28',NULL),(4,2,3,NULL,NULL,NULL,'ISOLATION_TEST_BIZ','test',NULL,NULL,NULL,NULL,NULL,'manual','contacted','hot',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-20 04:39:53','2026-08-20 05:24:45',NULL),(5,2,3,NULL,NULL,NULL,'ISOLATION_TEST_BIZ_8799','test',NULL,NULL,NULL,NULL,NULL,'manual','new','hot',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-20 06:23:26','2026-08-20 06:23:26',NULL);
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_logs`
--

DROP TABLE IF EXISTS `login_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `device` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('success','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `login_logs_user_id_created_at_index` (`user_id`,`created_at`),
  CONSTRAINT `login_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_logs`
--

LOCK TABLES `login_logs` WRITE;
/*!40000 ALTER TABLE `login_logs` DISABLE KEYS */;
INSERT INTO `login_logs` VALUES (1,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','testing',NULL,'success','2026-08-14 08:44:07'),(2,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-14 23:24:10'),(3,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-15 01:41:49'),(4,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-15 01:44:33'),(5,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-15 01:45:27'),(6,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-15 01:49:22'),(7,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-17 04:42:06'),(8,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-17 04:44:32'),(9,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-17 04:47:20'),(10,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-19 23:43:18'),(11,2,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 01:55:58'),(16,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 04:39:49'),(17,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 04:39:50'),(18,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 04:39:51'),(19,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 04:39:52'),(20,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 04:51:41'),(21,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 04:51:42'),(22,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 04:53:47'),(23,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 04:53:47'),(24,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 04:55:51'),(25,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 04:55:52'),(26,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 05:24:04'),(27,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 05:24:05'),(28,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 05:24:34'),(29,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 05:24:34'),(30,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 05:24:44'),(31,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 05:24:44'),(32,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 05:24:51'),(33,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 05:24:52'),(34,1,'127.0.0.1','Symfony','Other',NULL,'success','2026-08-20 06:03:28'),(35,1,'127.0.0.1','Symfony','Other',NULL,'success','2026-08-20 06:04:04'),(36,1,'127.0.0.1','Symfony','Other',NULL,'success','2026-08-20 06:04:23'),(37,1,'127.0.0.1','Symfony','Other',NULL,'success','2026-08-20 06:04:33'),(38,1,'127.0.0.1','Symfony','Other',NULL,'success','2026-08-20 06:04:49'),(39,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:20:55'),(40,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:20:56'),(41,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:21:47'),(42,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:21:47'),(43,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:21:48'),(44,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:21:49'),(45,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:22:15'),(46,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:22:16'),(47,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:22:17'),(48,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:22:18'),(49,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:23:18'),(50,3,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:23:20'),(51,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','Other',NULL,'success','2026-08-20 06:23:21'),(52,4,'127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; en-IN) WindowsPowerShell/5.1.19041.6456','test',NULL,'success','2026-08-20 06:23:22');
/*!40000 ALTER TABLE `login_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2024_01_01_000001_create_tenants_table',1),(5,'2024_01_01_000002_modify_users_table',1),(6,'2024_01_01_000003_create_plans_table',1),(7,'2024_01_01_000004_create_subscriptions_table',1),(8,'2024_01_01_000005_create_credit_wallets_table',1),(9,'2024_01_01_000006_create_credit_transactions_table',1),(10,'2024_01_01_000007_create_credit_packages_table',1),(11,'2024_01_01_000008_create_payments_table',1),(12,'2024_01_01_000009_create_invoices_table',1),(13,'2024_01_01_000010_create_searches_table',1),(14,'2024_01_01_000011_create_search_results_table',1),(15,'2024_01_01_000012_create_leads_table',1),(16,'2024_01_01_000013_create_lead_activities_table',1),(17,'2024_01_01_000014_create_lead_assignments_table',1),(18,'2024_01_01_000015_create_followups_table',1),(19,'2024_01_01_000016_create_quotations_table',1),(20,'2024_01_01_000017_create_quotation_items_table',1),(21,'2024_01_01_000018_create_deals_table',1),(22,'2024_01_01_000019_create_notifications_table',1),(23,'2024_01_01_000020_create_audit_logs_table',1),(24,'2024_01_01_000021_create_login_logs_table',1),(25,'2024_01_01_000022_create_api_usage_logs_table',1),(26,'2024_01_01_000023_create_settings_table',1),(27,'2024_01_01_000024_create_webhook_logs_table',1),(28,'2026_08_14_071859_create_permission_tables',1),(29,'2026_08_14_071901_create_personal_access_tokens_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`tenant_id`,`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  KEY `model_has_permissions_permission_id_foreign` (`permission_id`),
  KEY `model_has_permissions_team_foreign_key_index` (`tenant_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`tenant_id`,`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  KEY `model_has_roles_role_id_foreign` (`role_id`),
  KEY `model_has_roles_team_foreign_key_index` (`tenant_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1,0),(2,'App\\Models\\User',2,1),(2,'App\\Models\\User',3,2),(2,'App\\Models\\User',4,3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`),
  KEY `notifications_tenant_id_index` (`tenant_id`),
  CONSTRAINT `notifications_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `gateway` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'razorpay',
  `gateway_order_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_payment_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `status` enum('pending','success','failed','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint unsigned DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `refunded_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_user_id_foreign` (`user_id`),
  KEY `payments_tenant_id_index` (`tenant_id`),
  KEY `payments_gateway_order_id_index` (`gateway_order_id`),
  KEY `payments_gateway_payment_id_index` (`gateway_payment_id`),
  CONSTRAINT `payments_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,5,6,'razorpay','order_test_6a86dc49eedad','pay_test_6a86dc4a5ca89',NULL,500.00,'INR','success','credit_purchase','App\\Models\\CreditPackage',2,NULL,'2026-08-20 05:21:54',NULL,'2026-08-20 05:21:53','2026-08-20 05:21:54'),(2,5,7,'razorpay','order_test_6a86eaf8d8099','pay_test_6a86eaf917c86',NULL,500.00,'INR','success','credit_purchase','App\\Models\\CreditPackage',2,NULL,'2026-08-20 06:24:34',NULL,'2026-08-20 06:24:32','2026-08-20 06:24:34');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view_leads','sanctum','2026-08-14 08:22:25','2026-08-14 08:22:25'),(2,'create_leads','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(3,'edit_leads','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(4,'delete_leads','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(5,'assign_leads','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(6,'view_team_leads','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(7,'export_leads','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(8,'search_businesses','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(9,'use_credits','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(10,'buy_credits','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(11,'view_credits','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(12,'view_reports','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(13,'view_revenue','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(14,'view_usage_reports','sanctum','2026-08-14 08:22:26','2026-08-14 08:22:26'),(15,'manage_team','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(16,'view_team','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(17,'manage_subscription','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(18,'manage_settings','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(19,'create_followups','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(20,'edit_followups','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(21,'view_followups','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(22,'create_quotations','sanctum','2026-08-14 08:22:27','2026-08-14 08:22:27'),(23,'edit_quotations','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(24,'view_quotations','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(25,'create_deals','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(26,'view_deals','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(27,'log_activity','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(28,'view_activity','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',2,'default','8189f308cb27ec48b39f3d30b47efb116039258265325a503a6f7300c1864875','[\"*\"]',NULL,NULL,'2026-08-14 08:43:54','2026-08-14 08:43:54'),(2,'App\\Models\\User',2,'testing','4715d1e249580a23ab08ffc10e65a2a760cbbbbade3ac302afe8638d91ff728c','[\"*\"]','2026-08-14 08:44:36',NULL,'2026-08-14 08:44:07','2026-08-14 08:44:36'),(3,'App\\Models\\User',2,'test','0a7a3c68a0c8e0a3c62be22f5850c699bd95a4e51fb3e71d4d6da98db2791e82','[\"*\"]','2026-08-14 23:24:15',NULL,'2026-08-14 23:24:10','2026-08-14 23:24:15'),(4,'App\\Models\\User',2,'test','9d6380df26c85cf87526d4fdf5e64a6076f8bbf8d92427b4c07114b87bef08d5','[\"*\"]','2026-08-15 01:41:53',NULL,'2026-08-15 01:41:50','2026-08-15 01:41:53'),(5,'App\\Models\\User',2,'test','f441db3432b1083d64e058d06dfcb99cb7f35f0f625c466cac19068861f084e6','[\"*\"]','2026-08-15 01:44:34',NULL,'2026-08-15 01:44:33','2026-08-15 01:44:34'),(6,'App\\Models\\User',2,'test','e551f3564c2a42c6f917c769f86d5312a96bef6edb669092c477e6545c69b4ce','[\"*\"]','2026-08-15 01:45:48',NULL,'2026-08-15 01:45:27','2026-08-15 01:45:48'),(7,'App\\Models\\User',2,'test','64d3e9f51882204febc0ee35563803518e0a64792bfcae0acd84464183bc87e2','[\"*\"]','2026-08-15 01:49:25',NULL,'2026-08-15 01:49:22','2026-08-15 01:49:25'),(8,'App\\Models\\User',2,'test','9da4dcac27e8b29ee5aa8927532ad7d65fe7aaa2ac4a5ce50c3bc8b8ad37d69f','[\"*\"]','2026-08-17 04:42:08',NULL,'2026-08-17 04:42:06','2026-08-17 04:42:08'),(9,'App\\Models\\User',2,'test','b2e2eb5104565e53583dc47e40e3acb9b0cafef57767a002e33947324f400e4c','[\"*\"]','2026-08-17 04:44:35',NULL,'2026-08-17 04:44:32','2026-08-17 04:44:35'),(10,'App\\Models\\User',2,'test','890862a42552d23ec2101ee17e3680156a6ad2bccde775fa1e71031cad00d981','[\"*\"]','2026-08-17 04:47:30',NULL,'2026-08-17 04:47:20','2026-08-17 04:47:30'),(11,'App\\Models\\User',2,'test','99f7f60fe67a2b6ae5de6578bda14061b845ece00d9c6ca762c863d3dae514ad','[\"*\"]',NULL,NULL,'2026-08-19 23:43:20','2026-08-19 23:43:20'),(12,'App\\Models\\User',2,'test','5f88763187914481ea2196c2c6c90b645b6ea3769adb4fb53fec4ce76fa90580','[\"*\"]','2026-08-20 01:56:48',NULL,'2026-08-20 01:55:59','2026-08-20 01:56:48'),(13,'App\\Models\\User',3,'default','6a5985e7a75d09125bdc9d046785923b8abe224aa10235090c83fd85af665e74','[\"*\"]','2026-08-20 04:39:10',NULL,'2026-08-20 04:38:58','2026-08-20 04:39:10'),(14,'App\\Models\\User',4,'default','fa6affd95c3956285920202e56b49c76b8259bae77528844c362850d0dc3c1a4','[\"*\"]','2026-08-20 04:39:09',NULL,'2026-08-20 04:39:01','2026-08-20 04:39:09'),(15,'App\\Models\\User',3,'test','1c2dc240c052122733b7ed4d525d39eb6be3b3545fa48827d2f278f3c648c531','[\"*\"]','2026-08-20 04:40:09',NULL,'2026-08-20 04:39:51','2026-08-20 04:40:09'),(16,'App\\Models\\User',4,'test','0b43b81c748966b93654deecb5f4cd886df2c633b0fad877eea50a5e1f14f43f','[\"*\"]','2026-08-20 04:40:08',NULL,'2026-08-20 04:39:52','2026-08-20 04:40:08'),(17,'App\\Models\\User',3,'test','ec43d4535354a696417b34203fca44ecba00d39c7935dfe4be3b607b73a4e43e','[\"*\"]','2026-08-20 04:52:57',NULL,'2026-08-20 04:51:42','2026-08-20 04:52:57'),(18,'App\\Models\\User',3,'test','c6e9d9d0a5e072a908c671830a684cbd40ee009618d950d8d120ba78f5bde6dd','[\"*\"]','2026-08-20 04:54:21',NULL,'2026-08-20 04:53:48','2026-08-20 04:54:21'),(19,'App\\Models\\User',3,'test','95ad4a865d3428154545ca7a58b6dc887430c5e6cc712175c61ab83f5638cd22','[\"*\"]','2026-08-20 04:56:22',NULL,'2026-08-20 04:55:52','2026-08-20 04:56:22'),(20,'App\\Models\\User',3,'test','bbe23f54d40c17b7ec2c51aa9ca35a5f95d9c3adf021eca176a179a1710ddbbc','[\"*\"]','2026-08-20 05:24:06',NULL,'2026-08-20 05:24:05','2026-08-20 05:24:06'),(21,'App\\Models\\User',3,'test','57caeb68be0b9b8447ced06970409eeda9fc0d69d1a6d465fd8e7b7bba997f83','[\"*\"]','2026-08-20 05:24:35',NULL,'2026-08-20 05:24:34','2026-08-20 05:24:35'),(22,'App\\Models\\User',3,'test','c479e8f5855afb2ac2ac653386ca74860d786879d33a0f165f3c8faa6ca611da','[\"*\"]','2026-08-20 05:24:45',NULL,'2026-08-20 05:24:45','2026-08-20 05:24:45'),(23,'App\\Models\\User',3,'test','5d8e4d499aeccf515fb18d17b064eb6cadea0288162de868f91eafcdd44594e0','[\"*\"]','2026-08-20 05:24:52',NULL,'2026-08-20 05:24:52','2026-08-20 05:24:52'),(24,'App\\Models\\User',3,'test','c835f8a1dfbfcb51db86610b42ae4652d7d56e1ea3c96f75657cfcd79ca80515','[\"*\"]','2026-08-20 06:21:34',NULL,'2026-08-20 06:20:56','2026-08-20 06:21:34'),(25,'App\\Models\\User',3,'test','48352a0399db2f0d70de268fbfbec9026b18f61c5ede7791ded8e4dec922b2b8','[\"*\"]','2026-08-20 06:21:57',NULL,'2026-08-20 06:21:47','2026-08-20 06:21:57'),(26,'App\\Models\\User',4,'test','6fa8d098815df7473d3612864d451bf88d37fab20170eb693fd3cb8f73eb313f','[\"*\"]','2026-08-20 06:21:56',NULL,'2026-08-20 06:21:49','2026-08-20 06:21:56'),(27,'App\\Models\\User',3,'test','02942f590537a4892981510cb1dae3c9dce4806308061dab9ed722317927a1ad','[\"*\"]','2026-08-20 06:22:26',NULL,'2026-08-20 06:22:16','2026-08-20 06:22:26'),(28,'App\\Models\\User',4,'test','340e93e21e6b41d1ef471f55bd726afc2f6f7d446851444b4e5c70600e657187','[\"*\"]','2026-08-20 06:22:25',NULL,'2026-08-20 06:22:18','2026-08-20 06:22:25'),(29,'App\\Models\\User',3,'test','a18accbf31fb96f7fd2217f34330b9fc8a3a00adda63678fb31b49954d82d9fd','[\"*\"]','2026-08-20 06:23:35',NULL,'2026-08-20 06:23:20','2026-08-20 06:23:35'),(30,'App\\Models\\User',4,'test','48891d6e457c4d3cb732459fd50b199ae9d9e6f367c3e074318edf179b77ad7d','[\"*\"]','2026-08-20 06:23:35',NULL,'2026-08-20 06:23:22','2026-08-20 06:23:35'),(31,'App\\Models\\User',3,'rate_limit_test','b0ba6851c213cb16aaf447f26038d3af8e51845bff241e6fe3f9b50eae6bef16','[\"*\"]','2026-08-20 06:24:02',NULL,'2026-08-20 06:24:01','2026-08-20 06:24:02');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `billing_cycle` enum('monthly','yearly','one_time') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `credits_included` int NOT NULL DEFAULT '0',
  `max_users` int NOT NULL DEFAULT '1',
  `max_searches_per_day` int NOT NULL DEFAULT '10',
  `features` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_free` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'Free','free','Get started with limited features',0.00,'INR','monthly',50,1,5,'{\"ai\": false, \"api\": false, \"crm\": true, \"export\": false, \"search\": true, \"reports\": false, \"white_label\": false, \"opportunity_score\": false}',1,1,1,'2026-08-14 08:23:12','2026-08-14 08:23:12',NULL),(2,'Starter','starter','Perfect for individual sales professionals',499.00,'INR','monthly',1000,3,20,'{\"ai\": false, \"api\": false, \"crm\": true, \"export\": false, \"search\": true, \"reports\": true, \"white_label\": false, \"opportunity_score\": true}',1,0,2,'2026-08-14 08:23:12','2026-08-14 08:23:12',NULL),(3,'Growth','growth','For growing teams with advanced needs',999.00,'INR','monthly',3000,10,50,'{\"ai\": false, \"api\": false, \"crm\": true, \"export\": true, \"search\": true, \"reports\": true, \"white_label\": false, \"opportunity_score\": true}',1,0,3,'2026-08-14 08:23:12','2026-08-14 08:23:12',NULL),(4,'Professional','professional','Full-featured plan for serious businesses',1999.00,'INR','monthly',10000,25,100,'{\"ai\": true, \"api\": true, \"crm\": true, \"export\": true, \"search\": true, \"reports\": true, \"white_label\": false, \"opportunity_score\": true}',1,0,4,'2026-08-14 08:23:12','2026-08-14 08:23:12',NULL),(5,'Agency','agency','Enterprise plan for agencies and large teams',4999.00,'INR','monthly',50000,100,500,'{\"ai\": true, \"api\": true, \"crm\": true, \"export\": true, \"search\": true, \"reports\": true, \"white_label\": true, \"opportunity_score\": true}',1,0,5,'2026-08-14 08:23:12','2026-08-14 08:23:12',NULL);
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotation_items`
--

DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint unsigned NOT NULL,
  `service_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` int NOT NULL DEFAULT '1',
  `unit_price` decimal(12,2) NOT NULL,
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quotation_items_quotation_id_foreign` (`quotation_id`),
  CONSTRAINT `quotation_items_quotation_id_foreign` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotation_items`
--

LOCK TABLES `quotation_items` WRITE;
/*!40000 ALTER TABLE `quotation_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotation_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `lead_id` bigint unsigned NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `quotation_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `discount_type` enum('flat','percent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'flat',
  `gst_percent` decimal(5,2) NOT NULL DEFAULT '18.00',
  `gst_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INR',
  `validity_days` int NOT NULL DEFAULT '30',
  `valid_until` date DEFAULT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `sent_at` timestamp NULL DEFAULT NULL,
  `viewed_at` timestamp NULL DEFAULT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotations_quotation_number_unique` (`quotation_number`),
  KEY `quotations_lead_id_foreign` (`lead_id`),
  KEY `quotations_created_by_foreign` (`created_by`),
  KEY `quotations_tenant_id_status_index` (`tenant_id`,`status`),
  KEY `quotations_tenant_id_lead_id_index` (`tenant_id`,`lead_id`),
  CONSTRAINT `quotations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quotations_lead_id_foreign` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quotations_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,2),(1,3),(2,3),(3,3),(5,3),(6,3),(7,3),(8,3),(9,3),(11,3),(12,3),(13,3),(15,3),(16,3),(19,3),(20,3),(21,3),(22,3),(23,3),(24,3),(25,3),(26,3),(27,3),(28,3),(1,4),(2,4),(3,4),(8,4),(9,4),(11,4),(19,4),(20,4),(21,4),(22,4),(24,4),(25,4),(26,4),(27,4),(28,4),(1,5),(3,5),(19,5),(20,5),(21,5),(27,5),(28,5),(1,6),(11,6),(21,6),(24,6),(26,6),(28,6);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_tenant_id_name_guard_name_unique` (`tenant_id`,`name`,`guard_name`),
  KEY `roles_team_foreign_key_index` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,NULL,'super_admin','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(2,NULL,'tenant_owner','sanctum','2026-08-14 08:22:28','2026-08-14 08:22:28'),(3,NULL,'manager','sanctum','2026-08-14 08:22:29','2026-08-14 08:22:29'),(4,NULL,'sales_executive','sanctum','2026-08-14 08:22:30','2026-08-14 08:22:30'),(5,NULL,'telecaller','sanctum','2026-08-14 08:22:31','2026-08-14 08:22:31'),(6,NULL,'viewer','sanctum','2026-08-14 08:22:31','2026-08-14 08:22:31');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_results`
--

DROP TABLE IF EXISTS `search_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_results` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `search_id` bigint unsigned NOT NULL,
  `tenant_id` bigint unsigned NOT NULL,
  `place_reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formatted_address` text COLLATE utf8mb4_unicode_ci,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `review_count` int DEFAULT NULL,
  `opportunity_score` int DEFAULT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `raw_data` json DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `search_results_search_id_index` (`search_id`),
  KEY `search_results_tenant_id_place_reference_index` (`tenant_id`,`place_reference`),
  KEY `search_results_opportunity_score_index` (`opportunity_score`),
  KEY `search_results_place_reference_index` (`place_reference`),
  CONSTRAINT `search_results_search_id_foreign` FOREIGN KEY (`search_id`) REFERENCES `searches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `search_results_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_results`
--

LOCK TABLES `search_results` WRITE;
/*!40000 ALTER TABLE `search_results` DISABLE KEYS */;
INSERT INTO `search_results` VALUES (1,2,1,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Chennai, Tamil Nadu, India',13.0860000,80.2703000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.086, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2703, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:33','2026-08-17 04:44:33','2026-08-17 04:44:33'),(2,2,1,'demo_place_2','Chennai Web Solutions','web_design','Chennai, Tamil Nadu, India',13.0853000,80.2731000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0853, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2731, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:33','2026-08-17 04:44:33','2026-08-17 04:44:33'),(3,2,1,'demo_place_3','Murugan Traders','wholesale','Chennai, Tamil Nadu, India',13.0771000,80.2696000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.077100000000002, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26960000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:33','2026-08-17 04:44:33','2026-08-17 04:44:33'),(4,2,1,'demo_place_4','Anbu Restaurant','restaurant','Chennai, Tamil Nadu, India',13.0772000,80.2785000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0772, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.27850000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:33','2026-08-17 04:44:33','2026-08-17 04:44:33'),(5,2,1,'demo_place_5','Karthik Auto Repairs','auto_repair','Chennai, Tamil Nadu, India',13.0839000,80.2806000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.083900000000002, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2806, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:34','2026-08-17 04:44:34','2026-08-17 04:44:34'),(6,2,1,'demo_place_6','Priya Textiles','clothing_store','Chennai, Tamil Nadu, India',13.0873000,80.2654000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0873, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2654, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:34','2026-08-17 04:44:34','2026-08-17 04:44:34'),(7,2,1,'demo_place_7','Ganesh Dental Clinic','dentist','Chennai, Tamil Nadu, India',13.0796000,80.2758000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0796, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2758, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:34','2026-08-17 04:44:34','2026-08-17 04:44:34'),(8,2,1,'demo_place_8','Sunshine Academy','school','Chennai, Tamil Nadu, India',13.0807000,80.2732000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0807, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2732, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:34','2026-08-17 04:44:34','2026-08-17 04:44:34'),(9,2,1,'demo_place_9','RK Electronics','electronics_store','Chennai, Tamil Nadu, India',13.0789000,80.2794000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0789, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.27940000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:34','2026-08-17 04:44:34','2026-08-17 04:44:34'),(10,2,1,'demo_place_10','Balaji Construction','contractor','Chennai, Tamil Nadu, India',13.0781000,80.2618000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Chennai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0781, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.26180000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:44:34','2026-08-17 04:44:34','2026-08-17 04:44:34'),(11,3,1,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Coimbatore, Tamil Nadu, India',13.0748000,80.2645000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.074800000000002, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2645, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:22','2026-08-17 04:47:22','2026-08-17 04:47:22'),(12,3,1,'demo_place_2','Chennai Web Solutions','web_design','Coimbatore, Tamil Nadu, India',13.0878000,80.2752000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0878, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2752, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:22','2026-08-17 04:47:22','2026-08-17 04:47:22'),(13,3,1,'demo_place_3','Murugan Traders','wholesale','Coimbatore, Tamil Nadu, India',13.0801000,80.2740000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.080100000000002, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.274, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:22','2026-08-17 04:47:22','2026-08-17 04:47:22'),(14,3,1,'demo_place_4','Anbu Restaurant','restaurant','Coimbatore, Tamil Nadu, India',13.0835000,80.2682000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0835, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.26820000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:22','2026-08-17 04:47:22','2026-08-17 04:47:22'),(15,3,1,'demo_place_5','Karthik Auto Repairs','auto_repair','Coimbatore, Tamil Nadu, India',13.0750000,80.2752000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.075, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2752, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:23','2026-08-17 04:47:23','2026-08-17 04:47:23'),(16,3,1,'demo_place_6','Priya Textiles','clothing_store','Coimbatore, Tamil Nadu, India',13.0841000,80.2752000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0841, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2752, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:23','2026-08-17 04:47:23','2026-08-17 04:47:23'),(17,3,1,'demo_place_7','Ganesh Dental Clinic','dentist','Coimbatore, Tamil Nadu, India',13.0766000,80.2769000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0766, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.27690000000001, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:23','2026-08-17 04:47:23','2026-08-17 04:47:23'),(18,3,1,'demo_place_8','Sunshine Academy','school','Coimbatore, Tamil Nadu, India',13.0798000,80.2759000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0798, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.27590000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:23','2026-08-17 04:47:23','2026-08-17 04:47:23'),(19,3,1,'demo_place_9','RK Electronics','electronics_store','Coimbatore, Tamil Nadu, India',13.0872000,80.2659000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0872, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2659, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:23','2026-08-17 04:47:23','2026-08-17 04:47:23'),(20,3,1,'demo_place_10','Balaji Construction','contractor','Coimbatore, Tamil Nadu, India',13.0833000,80.2778000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Coimbatore, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0833, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2778, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-25 04:47:23','2026-08-17 04:47:23','2026-08-17 04:47:23'),(21,4,1,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Trichy, Tamil Nadu, India',13.0801000,80.2776000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.080100000000002, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2776, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:34','2026-08-20 01:56:34','2026-08-20 01:56:34'),(22,4,1,'demo_place_2','Chennai Web Solutions','web_design','Trichy, Tamil Nadu, India',13.0906000,80.2678000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0906, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.26780000000001, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(23,4,1,'demo_place_3','Murugan Traders','wholesale','Trichy, Tamil Nadu, India',13.0771000,80.2683000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.077100000000002, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26830000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(24,4,1,'demo_place_4','Anbu Restaurant','restaurant','Trichy, Tamil Nadu, India',13.0753000,80.2638000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0753, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2638, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(25,4,1,'demo_place_5','Karthik Auto Repairs','auto_repair','Trichy, Tamil Nadu, India',13.0733000,80.2674000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0733, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.26740000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(26,4,1,'demo_place_6','Priya Textiles','clothing_store','Trichy, Tamil Nadu, India',13.0765000,80.2730000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0765, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.27300000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(27,4,1,'demo_place_7','Ganesh Dental Clinic','dentist','Trichy, Tamil Nadu, India',13.0798000,80.2684000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0798, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2684, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(28,4,1,'demo_place_8','Sunshine Academy','school','Trichy, Tamil Nadu, India',13.0781000,80.2696000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0781, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.26960000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(29,4,1,'demo_place_9','RK Electronics','electronics_store','Trichy, Tamil Nadu, India',13.0748000,80.2637000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.074800000000002, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2637, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(30,4,1,'demo_place_10','Balaji Construction','contractor','Trichy, Tamil Nadu, India',13.0893000,80.2726000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Trichy, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0893, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.27260000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 01:56:35','2026-08-20 01:56:35','2026-08-20 01:56:35'),(31,5,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0768000,80.2694000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0768, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2694, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:25','2026-08-20 04:52:25','2026-08-20 04:52:25'),(32,5,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0772000,80.2729000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0772, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2729, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:27','2026-08-20 04:52:27','2026-08-20 04:52:27'),(33,5,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0899000,80.2736000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0899, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2736, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:27','2026-08-20 04:52:27','2026-08-20 04:52:27'),(34,5,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0770000,80.2700000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.077000000000002, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.27000000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:27','2026-08-20 04:52:27','2026-08-20 04:52:27'),(35,5,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0801000,80.2805000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.080100000000002, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2805, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:28','2026-08-20 04:52:28','2026-08-20 04:52:28'),(36,5,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0750000,80.2626000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.075, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2626, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:28','2026-08-20 04:52:28','2026-08-20 04:52:28'),(37,5,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0804000,80.2801000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0804, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2801, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:28','2026-08-20 04:52:28','2026-08-20 04:52:28'),(38,5,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0880000,80.2726000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.088, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.27260000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:29','2026-08-20 04:52:29','2026-08-20 04:52:29'),(39,5,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0793000,80.2667000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.079300000000002, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2667, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:29','2026-08-20 04:52:29','2026-08-20 04:52:29'),(40,5,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0805000,80.2636000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0805, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.26360000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:29','2026-08-20 04:52:29','2026-08-20 04:52:29'),(41,6,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0861000,80.2735000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0861, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2735, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:31','2026-08-20 04:52:31','2026-08-20 04:52:31'),(42,6,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0797000,80.2750000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0797, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.275, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:31','2026-08-20 04:52:31','2026-08-20 04:52:31'),(43,6,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0889000,80.2674000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0889, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26740000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:31','2026-08-20 04:52:31','2026-08-20 04:52:31'),(44,6,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0880000,80.2697000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.088, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2697, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:31','2026-08-20 04:52:31','2026-08-20 04:52:31'),(45,6,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0890000,80.2781000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.089, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27810000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:32','2026-08-20 04:52:32','2026-08-20 04:52:32'),(46,6,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0786000,80.2665000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.078600000000002, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.26650000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:32','2026-08-20 04:52:32','2026-08-20 04:52:32'),(47,6,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0728000,80.2802000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0728, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.28020000000001, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:32','2026-08-20 04:52:32','2026-08-20 04:52:32'),(48,6,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0850000,80.2685000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.085, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2685, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:33','2026-08-20 04:52:33','2026-08-20 04:52:33'),(49,6,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0875000,80.2637000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0875, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2637, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:33','2026-08-20 04:52:33','2026-08-20 04:52:33'),(50,6,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0870000,80.2769000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.087000000000002, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.27690000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:33','2026-08-20 04:52:33','2026-08-20 04:52:33'),(51,7,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0922000,80.2745000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0922, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2745, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:35','2026-08-20 04:52:35','2026-08-20 04:52:35'),(52,7,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0872000,80.2687000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0872, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.26870000000001, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:35','2026-08-20 04:52:35','2026-08-20 04:52:35'),(53,7,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0756000,80.2635000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0756, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26350000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:35','2026-08-20 04:52:35','2026-08-20 04:52:35'),(54,7,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0877000,80.2645000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.087700000000002, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2645, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:35','2026-08-20 04:52:35','2026-08-20 04:52:35'),(55,7,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0855000,80.2763000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0855, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2763, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:35','2026-08-20 04:52:35','2026-08-20 04:52:35'),(56,7,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0739000,80.2792000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0739, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2792, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:36','2026-08-20 04:52:36','2026-08-20 04:52:36'),(57,7,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0857000,80.2728000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0857, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2728, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:36','2026-08-20 04:52:36','2026-08-20 04:52:36'),(58,7,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0830000,80.2640000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.083, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.26400000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:36','2026-08-20 04:52:36','2026-08-20 04:52:36'),(59,7,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0734000,80.2775000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0734, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2775, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:36','2026-08-20 04:52:36','2026-08-20 04:52:36'),(60,7,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0828000,80.2783000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0828, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2783, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:36','2026-08-20 04:52:36','2026-08-20 04:52:36'),(61,8,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0887000,80.2617000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0887, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2617, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:38','2026-08-20 04:52:38','2026-08-20 04:52:38'),(62,8,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0825000,80.2651000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0825, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2651, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:38','2026-08-20 04:52:38','2026-08-20 04:52:38'),(63,8,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0761000,80.2632000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0761, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26320000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:38','2026-08-20 04:52:38','2026-08-20 04:52:38'),(64,8,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0811000,80.2725000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0811, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.27250000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:38','2026-08-20 04:52:38','2026-08-20 04:52:38'),(65,8,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0809000,80.2650000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.080900000000002, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.265, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:38','2026-08-20 04:52:38','2026-08-20 04:52:38'),(66,8,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0768000,80.2751000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0768, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.27510000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:39','2026-08-20 04:52:39','2026-08-20 04:52:39'),(67,8,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0823000,80.2632000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0823, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.26320000000001, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:39','2026-08-20 04:52:39','2026-08-20 04:52:39'),(68,8,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0846000,80.2794000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0846, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.27940000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:39','2026-08-20 04:52:39','2026-08-20 04:52:39'),(69,8,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0804000,80.2657000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0804, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.26570000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:39','2026-08-20 04:52:39','2026-08-20 04:52:39'),(70,8,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0903000,80.2754000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0903, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2754, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:39','2026-08-20 04:52:39','2026-08-20 04:52:39'),(71,9,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0905000,80.2711000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0905, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2711, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:40','2026-08-20 04:52:40','2026-08-20 04:52:40'),(72,9,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0856000,80.2770000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0856, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.277, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:41','2026-08-20 04:52:41','2026-08-20 04:52:41'),(73,9,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0860000,80.2707000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.086, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2707, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:41','2026-08-20 04:52:41','2026-08-20 04:52:41'),(74,9,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0925000,80.2719000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0925, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2719, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:41','2026-08-20 04:52:41','2026-08-20 04:52:41'),(75,9,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0867000,80.2656000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0867, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2656, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:41','2026-08-20 04:52:41','2026-08-20 04:52:41'),(76,9,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0921000,80.2747000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0921, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.27470000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:41','2026-08-20 04:52:41','2026-08-20 04:52:41'),(77,9,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0755000,80.2713000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.075500000000002, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.27130000000001, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:41','2026-08-20 04:52:41','2026-08-20 04:52:41'),(78,9,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0812000,80.2640000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0812, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.26400000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:42','2026-08-20 04:52:42','2026-08-20 04:52:42'),(79,9,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0910000,80.2774000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.091, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2774, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:42','2026-08-20 04:52:42','2026-08-20 04:52:42'),(80,9,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0920000,80.2640000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.092, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.26400000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:42','2026-08-20 04:52:42','2026-08-20 04:52:42'),(81,10,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0894000,80.2776000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0894, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2776, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:43','2026-08-20 04:52:43','2026-08-20 04:52:43'),(82,10,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0829000,80.2686000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0829, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2686, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(83,10,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0820000,80.2713000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.082, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.27130000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(84,10,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0877000,80.2733000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.087700000000002, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2733, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(85,10,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0728000,80.2687000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0728, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.26870000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(86,10,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0915000,80.2655000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.091500000000002, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2655, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(87,10,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0865000,80.2756000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0865, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.27560000000001, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(88,10,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0848000,80.2805000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0848, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2805, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:44','2026-08-20 04:52:44','2026-08-20 04:52:44'),(89,10,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0771000,80.2762000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.077100000000002, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2762, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:45','2026-08-20 04:52:45','2026-08-20 04:52:45'),(90,10,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0848000,80.2805000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0848, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2805, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:45','2026-08-20 04:52:45','2026-08-20 04:52:45'),(91,11,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0759000,80.2795000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0759, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2795, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(92,11,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0828000,80.2640000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0828, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.26400000000001, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(93,11,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0804000,80.2623000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0804, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26230000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(94,11,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0775000,80.2608000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0775, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2608, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(95,11,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0924000,80.2799000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0924, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27990000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(96,11,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0812000,80.2806000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0812, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2806, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(97,11,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0863000,80.2654000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0863, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2654, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(98,11,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0743000,80.2777000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0743, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.27770000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(99,11,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0772000,80.2782000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0772, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2782, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(100,11,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0867000,80.2763000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0867, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2763, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:46','2026-08-20 04:52:46','2026-08-20 04:52:46'),(101,12,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0739000,80.2667000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0739, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2667, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:48','2026-08-20 04:52:48','2026-08-20 04:52:48'),(102,12,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0899000,80.2740000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0899, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.274, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:48','2026-08-20 04:52:48','2026-08-20 04:52:48'),(103,12,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0861000,80.2711000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0861, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2711, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:48','2026-08-20 04:52:48','2026-08-20 04:52:48'),(104,12,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0767000,80.2655000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0767, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2655, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:49','2026-08-20 04:52:49','2026-08-20 04:52:49'),(105,12,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0758000,80.2798000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0758, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27980000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:49','2026-08-20 04:52:49','2026-08-20 04:52:49'),(106,12,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0922000,80.2665000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0922, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.26650000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:49','2026-08-20 04:52:49','2026-08-20 04:52:49'),(107,12,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0849000,80.2689000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0849, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2689, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:49','2026-08-20 04:52:49','2026-08-20 04:52:49'),(108,12,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0821000,80.2617000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0821, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2617, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:49','2026-08-20 04:52:49','2026-08-20 04:52:49'),(109,12,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0895000,80.2704000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0895, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.27040000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:49','2026-08-20 04:52:49','2026-08-20 04:52:49'),(110,12,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0755000,80.2630000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.075500000000002, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.263, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:50','2026-08-20 04:52:50','2026-08-20 04:52:50'),(111,13,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0842000,80.2731000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0842, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2731, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:52','2026-08-20 04:52:52','2026-08-20 04:52:52'),(112,13,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0857000,80.2702000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0857, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2702, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:52','2026-08-20 04:52:52','2026-08-20 04:52:52'),(113,13,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0862000,80.2778000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.086200000000002, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2778, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:53','2026-08-20 04:52:53','2026-08-20 04:52:53'),(114,13,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0906000,80.2673000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0906, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2673, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:53','2026-08-20 04:52:53','2026-08-20 04:52:53'),(115,13,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0847000,80.2774000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.084700000000002, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2774, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:53','2026-08-20 04:52:53','2026-08-20 04:52:53'),(116,13,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0908000,80.2743000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.090800000000002, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.27430000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:53','2026-08-20 04:52:53','2026-08-20 04:52:53'),(117,13,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0819000,80.2685000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0819, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2685, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:53','2026-08-20 04:52:53','2026-08-20 04:52:53'),(118,13,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0801000,80.2663000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.080100000000002, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2663, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:54','2026-08-20 04:52:54','2026-08-20 04:52:54'),(119,13,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0782000,80.2790000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0782, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.27900000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:54','2026-08-20 04:52:54','2026-08-20 04:52:54'),(120,13,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0858000,80.2707000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0858, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2707, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:54','2026-08-20 04:52:54','2026-08-20 04:52:54'),(121,14,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0920000,80.2684000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.092, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2684, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:55','2026-08-20 04:52:55','2026-08-20 04:52:55'),(122,14,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0768000,80.2710000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0768, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.271, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:55','2026-08-20 04:52:55','2026-08-20 04:52:55'),(123,14,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0730000,80.2617000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.073, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2617, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(124,14,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0923000,80.2805000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.092300000000002, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2805, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(125,14,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0921000,80.2700000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0921, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27000000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(126,14,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0765000,80.2742000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0765, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.27420000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(127,14,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0759000,80.2616000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0759, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2616, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(128,14,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0788000,80.2737000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0788, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2737, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(129,14,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0880000,80.2616000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.088, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2616, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(130,14,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0815000,80.2621000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0815, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2621, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:52:56','2026-08-20 04:52:56','2026-08-20 04:52:56'),(131,15,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0873000,80.2693000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0873, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2693, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:54','2026-08-20 04:53:54','2026-08-20 04:53:54'),(132,15,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0798000,80.2678000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0798, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.26780000000001, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:55','2026-08-20 04:53:55','2026-08-20 04:53:55'),(133,15,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0758000,80.2789000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0758, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.27890000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:55','2026-08-20 04:53:55','2026-08-20 04:53:55'),(134,15,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0733000,80.2669000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0733, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2669, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(135,15,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0730000,80.2720000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.073, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.272, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(136,15,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0898000,80.2767000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0898, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2767, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(137,15,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0820000,80.2748000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.082, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2748, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(138,15,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0788000,80.2685000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0788, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2685, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(139,15,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0919000,80.2659000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0919, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2659, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(140,15,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0736000,80.2701000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0736, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2701, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:53:56','2026-08-20 04:53:56','2026-08-20 04:53:56'),(141,16,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0923000,80.2800000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.092300000000002, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.28, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:10','2026-08-20 04:54:10','2026-08-20 04:54:10'),(142,16,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0747000,80.2772000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.074700000000002, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.27720000000001, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:10','2026-08-20 04:54:10','2026-08-20 04:54:10'),(143,16,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0757000,80.2757000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0757, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2757, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:11','2026-08-20 04:54:11','2026-08-20 04:54:11'),(144,16,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0894000,80.2801000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0894, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2801, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:11','2026-08-20 04:54:11','2026-08-20 04:54:11'),(145,16,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0896000,80.2772000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0896, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27720000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:11','2026-08-20 04:54:11','2026-08-20 04:54:11'),(146,16,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0760000,80.2753000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.076, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2753, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:12','2026-08-20 04:54:12','2026-08-20 04:54:12'),(147,16,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0869000,80.2689000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.086900000000002, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2689, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:12','2026-08-20 04:54:12','2026-08-20 04:54:12'),(148,16,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0741000,80.2695000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0741, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.26950000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:12','2026-08-20 04:54:12','2026-08-20 04:54:12'),(149,16,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0916000,80.2771000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0916, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2771, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:12','2026-08-20 04:54:12','2026-08-20 04:54:12'),(150,16,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0796000,80.2700000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0796, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.27000000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:12','2026-08-20 04:54:12','2026-08-20 04:54:12'),(151,17,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0755000,80.2771000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.075500000000002, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2771, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:14','2026-08-20 04:54:14','2026-08-20 04:54:14'),(152,17,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0878000,80.2609000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0878, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2609, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:14','2026-08-20 04:54:14','2026-08-20 04:54:14'),(153,17,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0857000,80.2657000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0857, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26570000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:14','2026-08-20 04:54:14','2026-08-20 04:54:14'),(154,17,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0817000,80.2721000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0817, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.27210000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:15','2026-08-20 04:54:15','2026-08-20 04:54:15'),(155,17,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0919000,80.2786000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0919, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27860000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:15','2026-08-20 04:54:15','2026-08-20 04:54:15'),(156,17,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0866000,80.2700000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0866, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.27000000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:15','2026-08-20 04:54:15','2026-08-20 04:54:15'),(157,17,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0743000,80.2758000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0743, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2758, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:16','2026-08-20 04:54:16','2026-08-20 04:54:16'),(158,17,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0847000,80.2791000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.084700000000002, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2791, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:16','2026-08-20 04:54:16','2026-08-20 04:54:16'),(159,17,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0785000,80.2677000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0785, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2677, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:17','2026-08-20 04:54:17','2026-08-20 04:54:17'),(160,17,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0799000,80.2730000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0799, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.27300000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:54:17','2026-08-20 04:54:17','2026-08-20 04:54:17'),(161,18,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0874000,80.2637000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0874, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2637, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:56','2026-08-20 04:55:56','2026-08-20 04:55:56'),(162,18,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0836000,80.2641000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0836, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2641, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:56','2026-08-20 04:55:56','2026-08-20 04:55:56'),(163,18,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0869000,80.2687000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.086900000000002, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.26870000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:56','2026-08-20 04:55:56','2026-08-20 04:55:56'),(164,18,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0813000,80.2616000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0813, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2616, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:56','2026-08-20 04:55:56','2026-08-20 04:55:56'),(165,18,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0830000,80.2747000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.083, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.27470000000001, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:56','2026-08-20 04:55:56','2026-08-20 04:55:56'),(166,18,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0815000,80.2626000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0815, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2626, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:56','2026-08-20 04:55:56','2026-08-20 04:55:56'),(167,18,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0874000,80.2776000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0874, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2776, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:57','2026-08-20 04:55:57','2026-08-20 04:55:57'),(168,18,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0800000,80.2801000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.08, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2801, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:57','2026-08-20 04:55:57','2026-08-20 04:55:57'),(169,18,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0826000,80.2765000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0826, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2765, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:57','2026-08-20 04:55:57','2026-08-20 04:55:57'),(170,18,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0827000,80.2713000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0827, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.27130000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:55:57','2026-08-20 04:55:57','2026-08-20 04:55:57'),(171,19,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0839000,80.2644000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.083900000000002, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.26440000000001, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:13','2026-08-20 04:56:13','2026-08-20 04:56:13'),(172,19,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0828000,80.2674000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0828, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.26740000000001, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:14','2026-08-20 04:56:14','2026-08-20 04:56:14'),(173,19,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0900000,80.2609000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.090000000000002, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2609, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:14','2026-08-20 04:56:14','2026-08-20 04:56:14'),(174,19,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0756000,80.2769000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0756, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.27690000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:14','2026-08-20 04:56:14','2026-08-20 04:56:14'),(175,19,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0912000,80.2611000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0912, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2611, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:14','2026-08-20 04:56:14','2026-08-20 04:56:14'),(176,19,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0856000,80.2687000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0856, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.26870000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:14','2026-08-20 04:56:14','2026-08-20 04:56:14'),(177,19,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0881000,80.2663000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0881, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2663, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:14','2026-08-20 04:56:14','2026-08-20 04:56:14'),(178,19,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0780000,80.2769000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.078, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.27690000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:15','2026-08-20 04:56:15','2026-08-20 04:56:15'),(179,19,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0757000,80.2659000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0757, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.2659, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:15','2026-08-20 04:56:15','2026-08-20 04:56:15'),(180,19,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0801000,80.2759000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.080100000000002, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.27590000000001, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:15','2026-08-20 04:56:15','2026-08-20 04:56:15'),(181,20,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0835000,80.2613000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0835, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2613, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:18','2026-08-20 04:56:18','2026-08-20 04:56:18'),(182,20,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0872000,80.2740000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0872, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.274, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:18','2026-08-20 04:56:18','2026-08-20 04:56:18'),(183,20,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0830000,80.2663000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.083, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2663, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:18','2026-08-20 04:56:18','2026-08-20 04:56:18'),(184,20,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0831000,80.2638000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.083100000000002, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2638, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:18','2026-08-20 04:56:18','2026-08-20 04:56:18'),(185,20,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0899000,80.2654000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0899, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2654, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:18','2026-08-20 04:56:18','2026-08-20 04:56:18'),(186,20,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0767000,80.2666000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0767, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.26660000000001, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:18','2026-08-20 04:56:18','2026-08-20 04:56:18'),(187,20,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0738000,80.2655000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0738, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2655, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:19','2026-08-20 04:56:19','2026-08-20 04:56:19'),(188,20,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0839000,80.2618000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.083900000000002, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.26180000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:19','2026-08-20 04:56:19','2026-08-20 04:56:19'),(189,20,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0806000,80.2619000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0806, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.26190000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:19','2026-08-20 04:56:19','2026-08-20 04:56:19'),(190,20,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0855000,80.2749000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0855, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2749, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 04:56:19','2026-08-20 04:56:19','2026-08-20 04:56:19'),(191,21,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0890000,80.2700000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.089, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.27000000000001, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:01','2026-08-20 06:21:01','2026-08-20 06:21:01'),(192,21,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0870000,80.2714000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.087000000000002, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2714, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:01','2026-08-20 06:21:01','2026-08-20 06:21:01'),(193,21,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0751000,80.2730000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0751, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.27300000000001, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(194,21,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0729000,80.2756000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0729, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.27560000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(195,21,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0791000,80.2749000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0791, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2749, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(196,21,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0811000,80.2693000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0811, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2693, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(197,21,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0854000,80.2718000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.085400000000002, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2718, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(198,21,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0854000,80.2774000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.085400000000002, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.2774, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(199,21,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0733000,80.2662000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0733, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.26620000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:02','2026-08-20 06:21:02','2026-08-20 06:21:02'),(200,21,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0841000,80.2669000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0841, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2669, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:03','2026-08-20 06:21:03','2026-08-20 06:21:03'),(201,22,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0884000,80.2662000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0884, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.26620000000001, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(202,22,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0734000,80.2788000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.0734, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2788, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(203,22,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0910000,80.2689000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.091, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2689, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(204,22,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0857000,80.2788000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.0857, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.2788, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(205,22,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0912000,80.2731000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.0912, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2731, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(206,22,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0884000,80.2750000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0884, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.275, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(207,22,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0821000,80.2672000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0821, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.2672, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:19','2026-08-20 06:21:19','2026-08-20 06:21:19'),(208,22,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0882000,80.2710000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0882, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.271, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:20','2026-08-20 06:21:20','2026-08-20 06:21:20'),(209,22,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0752000,80.2691000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.0752, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.26910000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:20','2026-08-20 06:21:20','2026-08-20 06:21:20'),(210,22,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0898000,80.2658000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.0898, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2658, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:20','2026-08-20 06:21:20','2026-08-20 06:21:20'),(211,23,2,'demo_place_1','Sri Lakshmi Digital Services','digital_marketing','Madurai, Tamil Nadu, India',13.0891000,80.2693000,'+91 98765 43210',NULL,3.2,15,70,'google_places','{\"name\": \"Sri Lakshmi Digital Services\", \"phone\": \"+91 98765 43210\", \"rating\": 3.2, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"digital_marketing\", \"latitude\": 13.0891, \"maps_url\": null, \"place_id\": \"demo_place_1\", \"longitude\": 80.2693, \"review_count\": 15, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:24','2026-08-20 06:21:24','2026-08-20 06:21:24'),(212,23,2,'demo_place_2','Chennai Web Solutions','web_design','Madurai, Tamil Nadu, India',13.0800000,80.2622000,'+91 98765 43211','http://example.com',4.1,42,48,'google_places','{\"name\": \"Chennai Web Solutions\", \"phone\": \"+91 98765 43211\", \"rating\": 4.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://example.com\", \"category\": \"web_design\", \"latitude\": 13.08, \"maps_url\": null, \"place_id\": \"demo_place_2\", \"longitude\": 80.2622, \"review_count\": 42, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:25','2026-08-20 06:21:25','2026-08-20 06:21:25'),(213,23,2,'demo_place_3','Murugan Traders','wholesale','Madurai, Tamil Nadu, India',13.0881000,80.2625000,'+91 98765 43212',NULL,2.8,8,70,'google_places','{\"name\": \"Murugan Traders\", \"phone\": \"+91 98765 43212\", \"rating\": 2.8, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"wholesale\", \"latitude\": 13.0881, \"maps_url\": null, \"place_id\": \"demo_place_3\", \"longitude\": 80.2625, \"review_count\": 8, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:26','2026-08-20 06:21:26','2026-08-20 06:21:26'),(214,23,2,'demo_place_4','Anbu Restaurant','restaurant','Madurai, Tamil Nadu, India',13.0747000,80.2618000,'+91 98765 43213','http://anburestaurant.in',4.5,230,54,'google_places','{\"name\": \"Anbu Restaurant\", \"phone\": \"+91 98765 43213\", \"rating\": 4.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://anburestaurant.in\", \"category\": \"restaurant\", \"latitude\": 13.074700000000002, \"maps_url\": null, \"place_id\": \"demo_place_4\", \"longitude\": 80.26180000000001, \"review_count\": 230, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:26','2026-08-20 06:21:26','2026-08-20 06:21:26'),(215,23,2,'demo_place_5','Karthik Auto Repairs','auto_repair','Madurai, Tamil Nadu, India',13.0800000,80.2622000,'+91 98765 43214',NULL,3.9,67,74,'google_places','{\"name\": \"Karthik Auto Repairs\", \"phone\": \"+91 98765 43214\", \"rating\": 3.9, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"auto_repair\", \"latitude\": 13.08, \"maps_url\": null, \"place_id\": \"demo_place_5\", \"longitude\": 80.2622, \"review_count\": 67, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:26','2026-08-20 06:21:26','2026-08-20 06:21:26'),(216,23,2,'demo_place_6','Priya Textiles','clothing_store','Madurai, Tamil Nadu, India',13.0822000,80.2746000,'+91 98765 43215','http://priyatextiles.com',4.0,105,50,'google_places','{\"name\": \"Priya Textiles\", \"phone\": \"+91 98765 43215\", \"rating\": 4, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://priyatextiles.com\", \"category\": \"clothing_store\", \"latitude\": 13.0822, \"maps_url\": null, \"place_id\": \"demo_place_6\", \"longitude\": 80.2746, \"review_count\": 105, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:27','2026-08-20 06:21:27','2026-08-20 06:21:27'),(217,23,2,'demo_place_7','Ganesh Dental Clinic','dentist','Madurai, Tamil Nadu, India',13.0874000,80.2725000,'+91 98765 43216',NULL,4.7,89,78,'google_places','{\"name\": \"Ganesh Dental Clinic\", \"phone\": \"+91 98765 43216\", \"rating\": 4.7, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"dentist\", \"latitude\": 13.0874, \"maps_url\": null, \"place_id\": \"demo_place_7\", \"longitude\": 80.27250000000001, \"review_count\": 89, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:27','2026-08-20 06:21:27','2026-08-20 06:21:27'),(218,23,2,'demo_place_8','Sunshine Academy','school','Madurai, Tamil Nadu, India',13.0817000,80.2665000,'+91 98765 43217','http://sunshineacademy.edu.in',3.5,33,44,'google_places','{\"name\": \"Sunshine Academy\", \"phone\": \"+91 98765 43217\", \"rating\": 3.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": \"http://sunshineacademy.edu.in\", \"category\": \"school\", \"latitude\": 13.0817, \"maps_url\": null, \"place_id\": \"demo_place_8\", \"longitude\": 80.26650000000001, \"review_count\": 33, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:27','2026-08-20 06:21:27','2026-08-20 06:21:27'),(219,23,2,'demo_place_9','RK Electronics','electronics_store','Madurai, Tamil Nadu, India',13.0800000,80.2772000,'+91 98765 43218',NULL,3.1,18,70,'google_places','{\"name\": \"RK Electronics\", \"phone\": \"+91 98765 43218\", \"rating\": 3.1, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"electronics_store\", \"latitude\": 13.08, \"maps_url\": null, \"place_id\": \"demo_place_9\", \"longitude\": 80.27720000000001, \"review_count\": 18, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:28','2026-08-20 06:21:28','2026-08-20 06:21:28'),(220,23,2,'demo_place_10','Balaji Construction','contractor','Madurai, Tamil Nadu, India',13.0824000,80.2689000,'+91 98765 43219',NULL,2.5,5,70,'google_places','{\"name\": \"Balaji Construction\", \"phone\": \"+91 98765 43219\", \"rating\": 2.5, \"address\": \"Madurai, Tamil Nadu, India\", \"website\": null, \"category\": \"contractor\", \"latitude\": 13.082400000000002, \"maps_url\": null, \"place_id\": \"demo_place_10\", \"longitude\": 80.2689, \"review_count\": 5, \"business_status\": \"OPERATIONAL\"}','2036-06-28 06:21:28','2026-08-20 06:21:28','2026-08-20 06:21:28');
/*!40000 ALTER TABLE `search_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searches`
--

DROP TABLE IF EXISTS `searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `radius` int DEFAULT NULL,
  `filters` json DEFAULT NULL,
  `result_count` int NOT NULL DEFAULT '0',
  `credits_used` int NOT NULL DEFAULT '0',
  `status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `api_provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_cost` decimal(8,4) NOT NULL DEFAULT '0.0000',
  `response_time_ms` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `searches_user_id_foreign` (`user_id`),
  KEY `searches_tenant_id_user_id_index` (`tenant_id`,`user_id`),
  KEY `searches_tenant_id_created_at_index` (`tenant_id`,`created_at`),
  KEY `searches_status_index` (`status`),
  CONSTRAINT `searches_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE,
  CONSTRAINT `searches_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searches`
--

LOCK TABLES `searches` WRITE;
/*!40000 ALTER TABLE `searches` DISABLE KEYS */;
INSERT INTO `searches` VALUES (1,1,2,'restaurant','restaurant','Chennai',NULL,NULL,NULL,NULL,0,0,'pending','google_places',0.0000,NULL,'2026-08-17 04:42:11','2026-08-17 04:42:11'),(2,1,2,'restaurant','restaurant','Chennai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-17 04:44:32','2026-08-17 04:44:34'),(3,1,2,'shop',NULL,'Coimbatore',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-17 04:47:21','2026-08-17 04:47:23'),(4,1,2,'salon',NULL,'Trichy',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,47,'2026-08-20 01:56:33','2026-08-20 01:56:36'),(5,2,3,'Hotel 3',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,126,'2026-08-20 04:52:23','2026-08-20 04:52:29'),(6,2,3,'Hotel 1',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:31','2026-08-20 04:52:33'),(7,2,3,'Hotel 2',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:34','2026-08-20 04:52:36'),(8,2,3,'Hotel 8',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:37','2026-08-20 04:52:39'),(9,2,3,'Hotel 9',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:40','2026-08-20 04:52:42'),(10,2,3,'Hotel 7',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:43','2026-08-20 04:52:45'),(11,2,3,'Hotel 10',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:45','2026-08-20 04:52:46'),(12,2,3,'Hotel 5',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:47','2026-08-20 04:52:50'),(13,2,3,'Hotel 4',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:52','2026-08-20 04:52:54'),(14,2,3,'Hotel 6',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:52:55','2026-08-20 04:52:56'),(15,2,3,'Hotel 1',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:53:54','2026-08-20 04:53:56'),(16,2,3,'Hotel 2',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:54:10','2026-08-20 04:54:13'),(17,2,3,'Hotel 4',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:54:14','2026-08-20 04:54:17'),(18,2,3,'Hotel 1',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:55:56','2026-08-20 04:55:57'),(19,2,3,'Hotel 2',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:56:13','2026-08-20 04:56:15'),(20,2,3,'Hotel 9',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 04:56:17','2026-08-20 04:56:19'),(21,2,3,'Hotel 1',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 06:21:01','2026-08-20 06:21:03'),(22,2,3,'Hotel 2',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 06:21:18','2026-08-20 06:21:20'),(23,2,3,'Hotel 5',NULL,'Madurai',NULL,NULL,NULL,NULL,10,5,'completed','google_places',0.0000,0,'2026-08-20 06:21:23','2026-08-20 06:21:28');
/*!40000 ALTER TABLE `searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('bXANchh8grZs3ChNsxHdtSaM7YxRgCytnvtJjHCB',1,'127.0.0.1','Symfony','eyJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwiX3Rva2VuIjoiR2JRNzVVNXhiMzdoRlpNY0dCWUc1OHZDeUs0a3FucVJ3ZVU4WGYxNiIsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2FkbWluXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImFkbWluLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1787225645),('MEQNbf4JmUuNkuiFTeagZ8Y647ZMFvrYFjAlyO8r',1,'127.0.0.1','Symfony','eyJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwiX3Rva2VuIjoiVTJJaGpEb2lneHc0QjRGaWV1bFU5cEJGUnhJWVphMWVSQ01MaE02UCIsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2FkbWluXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImFkbWluLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1787225613),('RH6UvT9Kjox4zbhSaUAvRQ3xOnpPPi44fNAQsaTc',1,'127.0.0.1','Symfony','eyJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwiX3Rva2VuIjoiZzNLRzczSTVHOG9Eb1RBUUhaeW1iZWRETURiVTY2TFNFNjNpbjJoYSIsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2FkbWluXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImFkbWluLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1787225689),('SArDkmfMhrIFG3bAnfr4iMVKss4mspdGeejbXRzH',1,'127.0.0.1','Symfony','eyJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwiX3Rva2VuIjoiN3ZSMHFnNXVDV21UN3pWTmtqZ1ZRS1daSmlSQUxwY2xyejA2djBRUSIsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2FkbWluXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImFkbWluLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1787225664),('xoZcpdCHh4w3ZEapVoYO7USaHobVVB7Qtt6kWCHq',1,'127.0.0.1','Symfony','eyJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6MSwiX3Rva2VuIjoiVzR2Q3hGWXZqTlVHSmQ0YTdtbk1OM0NUT0lFdkpucmZJRmFxTnpwWiIsIl9wcmV2aW91cyI6eyJ1cmwiOiJodHRwOlwvXC9sb2NhbGhvc3RcL2FkbWluXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImFkbWluLmRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1787225673);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `group` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_tenant_id_group_key_unique` (`tenant_id`,`group`,`key`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,NULL,'opportunity_score','website_opportunity','30','2026-08-14 08:23:13','2026-08-14 08:23:13'),(2,NULL,'opportunity_score','digital_presence_gap','20','2026-08-14 08:23:13','2026-08-14 08:23:13'),(3,NULL,'opportunity_score','business_relevance','15','2026-08-14 08:23:13','2026-08-14 08:23:13'),(4,NULL,'opportunity_score','business_activity','15','2026-08-14 08:23:13','2026-08-14 08:23:13'),(5,NULL,'opportunity_score','contact_availability','10','2026-08-14 08:23:13','2026-08-14 08:23:13'),(6,NULL,'opportunity_score','growth_potential','10','2026-08-14 08:23:13','2026-08-14 08:23:13'),(7,NULL,'credits','search_cost','5','2026-08-14 08:23:13','2026-08-14 08:23:13'),(8,NULL,'credits','detail_cost','2','2026-08-14 08:23:13','2026-08-14 08:23:13'),(9,NULL,'credits','ai_analysis_cost','10','2026-08-14 08:23:13','2026-08-14 08:23:13'),(10,NULL,'credits','enrichment_cost','3','2026-08-14 08:23:13','2026-08-14 08:23:13'),(11,NULL,'credits','low_credit_threshold_percent','20','2026-08-14 08:23:14','2026-08-14 08:23:14'),(12,NULL,'lead_config','default_statuses','[\"new\", \"contacted\", \"interested\", \"demo\", \"proposal\", \"negotiation\", \"won\", \"lost\"]','2026-08-14 08:23:14','2026-08-14 08:23:14'),(13,NULL,'service_rules','restaurant','{\"website\": \"high\", \"branding\": \"medium\", \"mobile_app\": \"medium\", \"digital_marketing\": \"high\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(14,NULL,'service_rules','textile','{\"website\": \"high\", \"branding\": \"high\", \"ecommerce\": \"high\", \"digital_marketing\": \"medium\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(15,NULL,'service_rules','builder','{\"website\": \"high\", \"branding\": \"high\", \"video_creation\": \"medium\", \"digital_marketing\": \"high\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(16,NULL,'service_rules','school','{\"crm\": \"medium\", \"website\": \"high\", \"mobile_app\": \"high\", \"digital_marketing\": \"medium\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(17,NULL,'service_rules','hotel','{\"website\": \"high\", \"branding\": \"medium\", \"mobile_app\": \"medium\", \"digital_marketing\": \"high\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(18,NULL,'service_rules','manufacturer','{\"crm\": \"high\", \"website\": \"high\", \"ecommerce\": \"medium\", \"custom_software\": \"high\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(19,NULL,'service_rules','salon','{\"website\": \"high\", \"branding\": \"medium\", \"mobile_app\": \"low\", \"digital_marketing\": \"high\"}','2026-08-14 08:23:14','2026-08-14 08:23:14'),(20,NULL,'service_rules','hospital','{\"website\": \"high\", \"mobile_app\": \"high\", \"custom_software\": \"high\", \"digital_marketing\": \"medium\"}','2026-08-14 08:23:14','2026-08-14 08:23:14');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint unsigned NOT NULL,
  `plan_id` bigint unsigned NOT NULL,
  `status` enum('active','expired','cancelled','trial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'trial',
  `starts_at` timestamp NOT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `cancelled_at` timestamp NULL DEFAULT NULL,
  `payment_id` bigint unsigned DEFAULT NULL,
  `auto_renew` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_plan_id_foreign` (`plan_id`),
  KEY `subscriptions_tenant_id_status_index` (`tenant_id`,`status`),
  KEY `subscriptions_expires_at_index` (`expires_at`),
  CONSTRAINT `subscriptions_plan_id_foreign` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,1,1,'trial','2026-08-14 08:43:53','2026-08-28 08:43:53',NULL,NULL,1,'2026-08-14 08:43:53','2026-08-14 08:43:53'),(2,2,1,'trial','2026-08-20 04:38:57','2026-09-03 04:38:57',NULL,NULL,1,'2026-08-20 04:38:57','2026-08-20 04:38:57'),(3,3,1,'trial','2026-08-20 04:39:00','2026-09-03 04:39:00',NULL,NULL,1,'2026-08-20 04:39:00','2026-08-20 04:39:00');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IN',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_category` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_locations` json DEFAULT NULL,
  `services_offered` json DEFAULT NULL,
  `status` enum('active','suspended','trial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'trial',
  `settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES (1,'Test Company','test-company-UCD9L','Test Company','test@example.com','9876543210','IN',NULL,NULL,NULL,NULL,'trial',NULL,'2026-08-14 08:43:52','2026-08-14 08:43:52',NULL),(2,'Isolation Tenant A','isolation-tenant-a-4qD1F','Isolation Tenant A','isolationA@test.com','9876543210','IN',NULL,NULL,NULL,NULL,'trial',NULL,'2026-08-20 04:38:53','2026-08-20 04:38:53',NULL),(3,'Isolation Tenant B','isolation-tenant-b-6euMJ','Isolation Tenant B','isolationB@test.com','9876543211','IN',NULL,NULL,NULL,NULL,'trial',NULL,'2026-08-20 04:38:59','2026-08-20 04:38:59',NULL),(4,'unverified-corp','unverified-corp-1787223038','Unverified Corp','unverified_1787223038@test.com',NULL,'IN',NULL,NULL,NULL,NULL,'active',NULL,'2026-08-20 05:20:38','2026-08-20 05:20:38',NULL),(5,'razorpay-test','razorpay-test-1787223112','Razorpay Test Tenant','rzp_test_1787223112@test.com',NULL,'IN',NULL,NULL,NULL,NULL,'active',NULL,'2026-08-20 05:21:52','2026-08-20 05:21:52',NULL);
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tenant_id` bigint unsigned DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','suspended','invited') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `login_count` int NOT NULL DEFAULT '0',
  `onboarding_completed` tinyint(1) NOT NULL DEFAULT '0',
  `is_super_admin` tinyint(1) NOT NULL DEFAULT '0',
  `settings` json DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_tenant_id_index` (`tenant_id`),
  CONSTRAINT `users_tenant_id_foreign` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Doxa Admin','admin@doxainfotech.com','2026-08-14 08:22:33','$2y$12$Wka36jKXiQwsF/yc14okjuV7/u1fD2/QrdeZsZXqgj1F35cJBBG1G',NULL,'2026-08-14 08:22:33','2026-08-20 06:04:49',NULL,NULL,NULL,'active','2026-08-20 06:04:49',5,1,1,NULL,NULL),(2,'Test User','test@example.com','2026-08-20 05:19:22','$2y$12$76jlJt8R6/oS7c5q7dXJze9D6w/IlLdBDpUx8V8BFRmdFcdJC0UO.',NULL,'2026-08-14 08:43:53','2026-08-20 05:19:22',1,'9876543210',NULL,'active','2026-08-20 01:55:58',11,0,0,NULL,NULL),(3,'User A','isolationA@test.com','2026-08-20 05:19:22','$2y$12$jl1JjtGi.yUD/Nca6m6UF.edL4Wu/dXtL7sW9fbrwwlK5N4vG02EW',NULL,'2026-08-20 04:38:54','2026-08-20 06:23:19',2,'9876543210',NULL,'active','2026-08-20 06:23:19',24,0,0,NULL,NULL),(4,'User B','isolationB@test.com','2026-08-20 05:19:22','$2y$12$Hlp7wFMaSYllXkF8hY4OeeSnxjnFUChR1LctxBzOxt494tVkPHq/O',NULL,'2026-08-20 04:39:00','2026-08-20 06:23:22',3,'9876543211',NULL,'active','2026-08-20 06:23:21',8,0,0,NULL,NULL),(5,'Unverified User','unverified_1787223038@test.com','2026-08-20 05:20:39','$2y$12$SfceXV7ViWOoUuDp2m5DweIVsh8zRn2BH0LfuRRnh82MGC0NbD5be',NULL,'2026-08-20 05:20:39','2026-08-20 05:20:39',4,'9123456780',NULL,'active',NULL,0,0,0,NULL,NULL),(6,'Rzp User','rzp_user_1787223112@test.com',NULL,'$2y$12$BvUXxUZ6sfrmV8eBimEJ9eN1MNYb2eyiRZ89z1aa6wX34y0g9KRje',NULL,'2026-08-20 05:21:53','2026-08-20 05:21:53',5,NULL,NULL,'active',NULL,0,0,0,NULL,NULL),(7,'Rzp User','rzp_user_1787226870@test.com',NULL,'$2y$12$MWTwsUSuQfll/HDBC92EBuZYN0gDZNMCnefJ/7J3kJbieqmQ4hZwe',NULL,'2026-08-20 06:24:30','2026-08-20 06:24:30',5,NULL,NULL,'active',NULL,0,0,0,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_logs`
--

DROP TABLE IF EXISTS `webhook_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gateway` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` json NOT NULL,
  `processed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `webhook_logs_event_id_unique` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_logs`
--

LOCK TABLES `webhook_logs` WRITE;
/*!40000 ALTER TABLE `webhook_logs` DISABLE KEYS */;
INSERT INTO `webhook_logs` VALUES (1,'wh_6a86dc4a5d07a','razorpay','payment.captured','{\"event\": \"payment.captured\", \"entity\": \"event\", \"payload\": {\"payment\": {\"entity\": {\"id\": \"pay_test_6a86dc4a5ca89\", \"amount\": 50000, \"entity\": \"payment\", \"status\": \"captured\", \"currency\": \"INR\", \"order_id\": \"order_test_6a86dc49eedad\"}}}, \"contains\": [\"payment\"], \"account_id\": \"acc_test123\"}',0,'2026-08-20 05:21:54','2026-08-20 05:21:54'),(2,'wh_6a86dc4ab2cea','razorpay','payment.captured','{\"event\": \"payment.captured\", \"entity\": \"event\", \"payload\": {\"payment\": {\"entity\": {\"id\": \"pay_test_6a86dc4a5ca89\", \"amount\": 50000, \"entity\": \"payment\", \"status\": \"captured\", \"currency\": \"INR\", \"order_id\": \"order_test_6a86dc49eedad\"}}}, \"contains\": [\"payment\"], \"account_id\": \"acc_test123\"}',1,'2026-08-20 05:21:54','2026-08-20 05:21:55'),(3,'wh_6a86eaf97a2df','razorpay','payment.captured','{\"event\": \"payment.captured\", \"entity\": \"event\", \"payload\": {\"payment\": {\"entity\": {\"id\": \"pay_test_6a86eaf917c86\", \"amount\": 50000, \"entity\": \"payment\", \"status\": \"captured\", \"currency\": \"INR\", \"order_id\": \"order_test_6a86eaf8d8099\"}}}, \"contains\": [\"payment\"], \"account_id\": \"acc_test123\"}',0,'2026-08-20 06:24:33','2026-08-20 06:24:33'),(4,'wh_6a86eaf9edf9b','razorpay','payment.captured','{\"event\": \"payment.captured\", \"entity\": \"event\", \"payload\": {\"payment\": {\"entity\": {\"id\": \"pay_test_6a86eaf917c86\", \"amount\": 50000, \"entity\": \"payment\", \"status\": \"captured\", \"currency\": \"INR\", \"order_id\": \"order_test_6a86eaf8d8099\"}}}, \"contains\": [\"payment\"], \"account_id\": \"acc_test123\"}',1,'2026-08-20 06:24:33','2026-08-20 06:24:34');
/*!40000 ALTER TABLE `webhook_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-20 17:25:37
